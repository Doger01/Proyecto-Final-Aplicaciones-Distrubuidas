# Frontend - México Profundo

Frontend web para la Plataforma México Profundo desarrollado con HTML, CSS y JavaScript vanilla.

## Características

- **Diseño Responsivo**: Funciona en desktop, tablet y móvil
- **Colores**: Fondo blanco con tonalidades azules como solicitado
- **Funcionalidad Completa**: Conecta con la API REST
- **Sin Frameworks**: HTML, CSS y JavaScript puro

## Archivos

```
📄 index.html    # Estructura principal de la aplicación
📄 styles.css    # Estilos con tema azul y blanco
📄 script.js     # Funcionalidad JavaScript
📄 README.md     # Esta documentación
```

## Funcionalidades

### 🏠 **Página Principal**
- Hero section con estadísticas en tiempo real
- Navegación intuitiva
- Estado de la API en tiempo real

### 👥 **Sección Artesanos**
- Lista de oferentes registrados
- Información de ubicación y tipo
- Enlaces a micrositios

### 🔐 **Autenticación**
- Formulario de login
- Formulario de registro
- Perfil de usuario
- Manejo de tokens JWT

### 📱 **Características Técnicas**
- Responsive design
- Notificaciones toast
- Manejo de errores
- Almacenamiento local de tokens

## Instalación y Uso

### 1. Asegurar que la API esté corriendo
```bash
cd ../Alcance1
npm run dev
```

### 2. Abrir el frontend
Simplemente abre `index.html` en tu navegador web o usa un servidor local:

```bash
# Con Python
python -m http.server 3000

# Con Node.js (si tienes http-server instalado)
npx http-server -p 3000

# O simplemente abre index.html en tu navegador
```

### 3. Acceder a la aplicación
- URL: http://localhost:3000 (si usas servidor local)
- O directamente abriendo index.html

## Funcionalidades Implementadas

### ✅ **Navegación**
- Menú de navegación fijo
- Cambio de secciones dinámico
- Indicador de sección activa

### ✅ **Conexión con API**
- Verificación de estado de la API
- Carga de oferentes desde la base de datos
- Estadísticas en tiempo real
- Manejo de errores de conexión

### ✅ **Autenticación**
- Login con email y contraseña
- Registro de nuevos usuarios
- Almacenamiento seguro de tokens
- Perfil de usuario
- Cerrar sesión

### ✅ **Interfaz de Usuario**
- Diseño moderno y limpio
- Colores azules sobre fondo blanco
- Iconos de Font Awesome
- Animaciones suaves
- Notificaciones toast

## Paleta de Colores

```css
/* Azules Principales */
--primary-blue: #2563eb    /* Azul principal */
--secondary-blue: #3b82f6  /* Azul secundario */
--light-blue: #dbeafe     /* Azul claro */
--dark-blue: #1e40af      /* Azul oscuro */
--accent-blue: #60a5fa    /* Azul acento */

/* Fondos */
--white: #ffffff          /* Fondo principal */
--light-gray: #f8fafc     /* Fondo alternativo */
```

## Estructura de Componentes

### **Header**
- Logo y título de la plataforma
- Menú de navegación
- Responsive con colapso en móvil

### **Secciones**
- **Inicio**: Hero con estadísticas
- **Oferentes**: Grid de artesanos
- **Productos**: Placeholder para futuro desarrollo
- **Auth**: Login, registro y perfil

### **Footer**
- Información del proyecto
- Estado de la API
- Enlaces adicionales

## Responsive Design

- **Desktop**: Layout completo con grid de 3 columnas
- **Tablet**: Grid de 2 columnas, navegación adaptada
- **Móvil**: Layout de 1 columna, menú colapsado

## Próximas Funcionalidades

- Catálogo de productos
- Carrito de compras
- Procesamiento de pagos
- Gestión de pedidos
- Panel de administración para oferentes

## Compatibilidad

- Chrome 80+
- Firefox 75+
- Safari 13+
- Edge 80+

El frontend está listo para usar y se conecta automáticamente con tu API REST de México Profundo.