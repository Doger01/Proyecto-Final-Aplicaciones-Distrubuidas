// Configuración de la API
const API_URL = 'http://localhost:5000';

// Estado de la aplicación
let currentUser = null;
let authToken = null;

// Inicialización
document.addEventListener('DOMContentLoaded', function() {
    // Verificar si hay token guardado
    authToken = localStorage.getItem('authToken');
    if (authToken) {
        loadUserProfile();
    }
    
    // Cargar datos iniciales
    checkApiStatus();
    loadOferentes();
    loadStats();
    
    // Configurar navegación
    setupNavigation();
});

// Navegación
function setupNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const section = link.getAttribute('href').substring(1);
            showSection(section);
            
            // Actualizar navegación activa
            navLinks.forEach(l => l.classList.remove('active'));
            link.classList.add('active');
        });
    });
}

function showSection(sectionId) {
    // Ocultar todas las secciones
    const sections = document.querySelectorAll('.section');
    sections.forEach(section => section.classList.remove('active'));
    
    // Mostrar sección seleccionada
    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
        targetSection.classList.add('active');
    }
    
    // Actualizar navegación
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === `#${sectionId}`) {
            link.classList.add('active');
        }
    });
}

// API Functions
async function apiCall(endpoint, options = {}) {
    try {
        const config = {
            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            },
            ...options
        };
        
        if (authToken) {
            config.headers.Authorization = `Bearer ${authToken}`;
        }
        
        const response = await fetch(`${API_URL}${endpoint}`, config);
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.message || 'Error en la petición');
        }
        
        return data;
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}

// Verificar estado de la API
async function checkApiStatus() {
    try {
        const response = await apiCall('/api/health');
        const statusElement = document.getElementById('api-status');
        statusElement.innerHTML = '<i class="fas fa-circle"></i> API Online';
        statusElement.className = 'api-status online';
    } catch (error) {
        const statusElement = document.getElementById('api-status');
        statusElement.innerHTML = '<i class="fas fa-circle"></i> API Offline';
        statusElement.className = 'api-status offline';
    }
}

// Cargar estadísticas
async function loadStats() {
    try {
        // Cargar oferentes para contar
        const oferentesData = await apiCall('/api/oferentes');
        document.getElementById('total-oferentes').textContent = oferentesData.oferentes?.length || 0;
        
        // Los productos están en desarrollo, mostrar 0
        document.getElementById('total-productos').textContent = '0';
        
    } catch (error) {
        console.error('Error cargando estadísticas:', error);
    }
}

// Cargar oferentes
async function loadOferentes() {
    const loadingElement = document.getElementById('oferentes-loading');
    const gridElement = document.getElementById('oferentes-grid');
    
    try {
        loadingElement.style.display = 'block';
        gridElement.innerHTML = '';
        
        const data = await apiCall('/api/oferentes');
        const oferentes = data.oferentes || [];
        
        loadingElement.style.display = 'none';
        
        if (oferentes.length === 0) {
            gridElement.innerHTML = `
                <div class="info-card">
                    <i class="fas fa-users"></i>
                    <h3>No hay artesanos registrados</h3>
                    <p>Sé el primero en registrarte como artesano en México Profundo.</p>
                </div>
            `;
            return;
        }
        
        oferentes.forEach(oferente => {
            const card = createOferenteCard(oferente);
            gridElement.appendChild(card);
        });
        
    } catch (error) {
        loadingElement.style.display = 'none';
        gridElement.innerHTML = `
            <div class="info-card">
                <i class="fas fa-exclamation-triangle"></i>
                <h3>Error al cargar artesanos</h3>
                <p>No se pudieron cargar los artesanos. Verifica que la API esté funcionando.</p>
            </div>
        `;
        console.error('Error cargando oferentes:', error);
    }
}

// Crear tarjeta de oferente
function createOferenteCard(oferente) {
    const card = document.createElement('div');
    card.className = 'oferente-card';
    
    const tipoTexto = {
        'artesano': 'Artesano',
        'comunidad': 'Comunidad',
        'cooperativa': 'Cooperativa'
    };
    
    card.innerHTML = `
        <div class="oferente-header">
            <div class="oferente-type">${tipoTexto[oferente.tipoOferente] || oferente.tipoOferente}</div>
            <div class="oferente-name">${oferente.datosPersonales.nombreComercial}</div>
        </div>
        <div class="oferente-body">
            <div class="oferente-location">
                <i class="fas fa-map-marker-alt"></i>
                <span>${oferente.ubicacion.localidad}, ${oferente.ubicacion.estado}</span>
            </div>
            ${oferente.micrositio ? `
                <a href="#" class="oferente-url" onclick="visitMicrositio('${oferente.micrositio.subdominio}')">
                    <i class="fas fa-external-link-alt"></i>
                    <span>${oferente.micrositio.url}</span>
                </a>
            ` : ''}
        </div>
    `;
    
    return card;
}

// Visitar micrositio
function visitMicrositio(subdominio) {
    showToast(`Visitando micrositio: ${subdominio}`, 'success');
    // En una implementación real, esto abriría el micrositio
    console.log('Visitando micrositio:', subdominio);
}

// Autenticación
async function handleLogin(event) {
    event.preventDefault();
    
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    
    try {
        const data = await apiCall('/api/auth/login', {
            method: 'POST',
            body: JSON.stringify({
                correo: email,
                password: password
            })
        });
        
        authToken = data.token;
        currentUser = data.usuario;
        localStorage.setItem('authToken', authToken);
        
        showUserProfile();
        showToast(`¡Bienvenido, ${currentUser.nombre}!`, 'success');
        
    } catch (error) {
        showToast(`Error al iniciar sesión: ${error.message}`, 'error');
    }
}

async function handleRegister(event) {
    event.preventDefault();
    
    const formData = {
        nombre: document.getElementById('register-nombre').value,
        apellidos: document.getElementById('register-apellidos').value,
        correo: document.getElementById('register-email').value,
        telefono: document.getElementById('register-telefono').value,
        password: document.getElementById('register-password').value,
        tipo: document.getElementById('register-tipo').value
    };
    
    try {
        const data = await apiCall('/api/auth/register', {
            method: 'POST',
            body: JSON.stringify(formData)
        });
        
        authToken = data.token;
        currentUser = data.usuario;
        localStorage.setItem('authToken', authToken);
        
        showUserProfile();
        showToast(`¡Cuenta creada exitosamente! Bienvenido, ${currentUser.nombre}!`, 'success');
        
        // Recargar oferentes si es un nuevo oferente
        if (formData.tipo === 'oferente') {
            setTimeout(() => {
                loadOferentes();
                loadStats();
            }, 1000);
        }
        
    } catch (error) {
        showToast(`Error al crear cuenta: ${error.message}`, 'error');
    }
}

async function loadUserProfile() {
    try {
        const data = await apiCall('/api/auth/profile');
        currentUser = data.usuario;
        showUserProfile();
    } catch (error) {
        // Token inválido, limpiar
        localStorage.removeItem('authToken');
        authToken = null;
        currentUser = null;
    }
}

function showUserProfile() {
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const profileForm = document.getElementById('user-profile');
    const profileInfo = document.getElementById('profile-info');
    
    loginForm.classList.add('hidden');
    registerForm.classList.add('hidden');
    profileForm.classList.remove('hidden');
    
    profileInfo.innerHTML = `
        <div class="profile-field">
            <strong>Nombre:</strong>
            <span>${currentUser.datosPersonales.nombre} ${currentUser.datosPersonales.apellidos}</span>
        </div>
        <div class="profile-field">
            <strong>Email:</strong>
            <span>${currentUser.datosPersonales.correo}</span>
        </div>
        <div class="profile-field">
            <strong>Teléfono:</strong>
            <span>${currentUser.datosPersonales.telefono}</span>
        </div>
        <div class="profile-field">
            <strong>Tipo de Usuario:</strong>
            <span>${currentUser.tipo === 'oferente' ? 'Artesano/Oferente' : 'Comprador'}</span>
        </div>
        <div class="profile-field">
            <strong>Fecha de Registro:</strong>
            <span>${new Date(currentUser.fechaRegistro).toLocaleDateString()}</span>
        </div>
    `;
}

function showLoginForm() {
    document.getElementById('login-form').classList.remove('hidden');
    document.getElementById('register-form').classList.add('hidden');
    document.getElementById('user-profile').classList.add('hidden');
}

function showRegisterForm() {
    document.getElementById('login-form').classList.add('hidden');
    document.getElementById('register-form').classList.remove('hidden');
    document.getElementById('user-profile').classList.add('hidden');
}

function logout() {
    localStorage.removeItem('authToken');
    authToken = null;
    currentUser = null;
    
    showLoginForm();
    showToast('Sesión cerrada exitosamente', 'success');
}

// Notificaciones Toast
function showToast(message, type = 'success') {
    const toast = document.getElementById('toast');
    const icon = toast.querySelector('.toast-icon');
    const messageElement = toast.querySelector('.toast-message');
    
    // Configurar contenido
    messageElement.textContent = message;
    
    // Configurar icono y clase
    toast.className = `toast ${type}`;
    if (type === 'success') {
        icon.className = 'toast-icon fas fa-check-circle';
    } else if (type === 'error') {
        icon.className = 'toast-icon fas fa-exclamation-circle';
    }
    
    // Mostrar toast
    toast.classList.add('show');
    
    // Ocultar después de 4 segundos
    setTimeout(() => {
        toast.classList.remove('show');
    }, 4000);
}

// Funciones auxiliares
function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('es-MX', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

// Verificar estado de la API cada 30 segundos
setInterval(checkApiStatus, 30000);