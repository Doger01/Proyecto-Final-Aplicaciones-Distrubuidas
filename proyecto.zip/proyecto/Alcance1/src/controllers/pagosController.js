// Controlador de Pagos Simulados
const { obtenerDB } = require('../utils/database');
const { ObjectId } = require('mongodb');
// Función para crear errores personalizados
const crearError = (tipo, mensaje, status = 500) => {
  const error = new Error(mensaje);
  error.type = tipo;
  error.status = status;
  return error;
};
const { procesarPago, obtenerEstadoPago, simularWebhook, generarReporteVentas } = require('../services/mockPaymentService');

// Procesar pago simulado
const procesarPagoSimulado = async (req, res, next) => {
  try {
    const { pedidoId, metodoPago, datosPago } = req.body;
    const db = obtenerDB();

    // Verificar que el pedido existe y pertenece al usuario
    const pedido = await db.collection('pedidos').findOne({ 
      _id: new ObjectId(pedidoId),
      compradorId: new ObjectId(req.usuario.id)
    });

    if (!pedido) {
      throw crearError('not_found', 'Pedido no encontrado o no autorizado', 404);
    }

    if (pedido.pago.estado === 'completado') {
      throw crearError('conflict', 'El pedido ya ha sido pagado', 409);
    }

    // Procesar pago simulado
    const resultadoPago = await procesarPago(pedidoId, metodoPago, datosPago);

    res.json({
      message: 'Pago procesado exitosamente (simulado)',
      pago: resultadoPago
    });

  } catch (error) {
    next(error);
  }
};

// Obtener estado de un pago
const obtenerEstadoPagoController = async (req, res, next) => {
  try {
    const { transaccionId } = req.params;
    
    const estadoPago = await obtenerEstadoPago(transaccionId);

    res.json({
      pago: estadoPago
    });

  } catch (error) {
    next(error);
  }
};

// Simular webhook de pago (solo para testing)
const simularWebhookController = async (req, res, next) => {
  try {
    const { transaccionId, nuevoEstado } = req.body;

    // Solo permitir en modo desarrollo
    if (process.env.NODE_ENV === 'production') {
      throw crearError('authorization', 'No disponible en producción', 403);
    }

    await simularWebhook(transaccionId, nuevoEstado);

    res.json({
      message: 'Webhook simulado procesado exitosamente'
    });

  } catch (error) {
    next(error);
  }
};

// Obtener historial de pagos del usuario
const obtenerHistorialPagos = async (req, res, next) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const db = obtenerDB();

    const skip = (page - 1) * limit;

    // Obtener pedidos con pagos del usuario
    const pedidos = await db.collection('pedidos').aggregate([
      { 
        $match: { 
          compradorId: new ObjectId(req.usuario.id),
          'pago.estado': { $in: ['completado', 'fallido'] }
        }
      },
      {
        $lookup: {
          from: 'oferentes',
          localField: 'oferenteId',
          foreignField: '_id',
          as: 'oferente'
        }
      },
      {
        $project: {
          numeroPedido: 1,
          'totales.total': 1,
          'pago.transaccionId': 1,
          'pago.estado': 1,
          'pago.fechaPago': 1,
          'pago.metodo': 1,
          fechaCreacion: 1,
          'oferente.datosPersonales.nombreComercial': 1
        }
      },
      { $sort: { 'pago.fechaPago': -1 } },
      { $skip: skip },
      { $limit: parseInt(limit) }
    ]).toArray();

    const total = await db.collection('pedidos').countDocuments({
      compradorId: new ObjectId(req.usuario.id),
      'pago.estado': { $in: ['completado', 'fallido'] }
    });

    res.json({
      pagos: pedidos,
      paginacion: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    next(error);
  }
};

// Generar reporte de ventas (para oferentes)
const generarReporteVentasController = async (req, res, next) => {
  try {
    const { fechaInicio, fechaFin } = req.query;
    const db = obtenerDB();

    // Obtener el oferente del usuario actual
    const oferente = await db.collection('oferentes').findOne({
      'datosPersonales.correo': req.usuario.email
    });

    if (!oferente) {
      throw crearError('not_found', 'Perfil de oferente no encontrado', 404);
    }

    const reporte = await generarReporteVentas(oferente._id, fechaInicio, fechaFin);

    // Obtener detalles adicionales
    const detallesVentas = await db.collection('transacciones').aggregate([
      {
        $match: {
          oferenteId: oferente._id,
          estado: 'completado',
          ...(fechaInicio || fechaFin ? {
            fechaTransaccion: {
              ...(fechaInicio && { $gte: new Date(fechaInicio) }),
              ...(fechaFin && { $lte: new Date(fechaFin) })
            }
          } : {})
        }
      },
      {
        $lookup: {
          from: 'pedidos',
          localField: 'pedidoId',
          foreignField: '_id',
          as: 'pedido'
        }
      },
      {
        $project: {
          monto: 1,
          'distribucion.oferente': 1,
          fechaTransaccion: 1,
          'pasarelaPago.proveedor': 1,
          'pedido.numeroPedido': 1
        }
      },
      { $sort: { fechaTransaccion: -1 } },
      { $limit: 50 } // Últimas 50 transacciones
    ]).toArray();

    res.json({
      reporte: reporte,
      detalles: detallesVentas,
      periodo: {
        inicio: fechaInicio || 'Desde el inicio',
        fin: fechaFin || 'Hasta ahora'
      }
    });

  } catch (error) {
    next(error);
  }
};

// Obtener métodos de pago disponibles
const obtenerMetodosPago = async (req, res, next) => {
  try {
    const metodos = [
      {
        id: 'stripe',
        nombre: 'Tarjeta de Crédito/Débito',
        descripcion: 'Visa, Mastercard, American Express',
        comision: 3.6,
        activo: true,
        simulado: true
      },
      {
        id: 'mercadopago',
        nombre: 'MercadoPago',
        descripcion: 'Tarjetas, OXXO, transferencias',
        comision: 4.2,
        activo: true,
        simulado: true
      }
    ];

    res.json({
      metodos: metodos,
      nota: 'Todos los pagos son simulados para fines educativos'
    });

  } catch (error) {
    next(error);
  }
};

// Calcular comisiones de un monto
const calcularComisiones = async (req, res, next) => {
  try {
    const { monto, metodoPago } = req.query;

    if (!monto || isNaN(monto)) {
      throw crearError('validation', 'Monto inválido', 400);
    }

    const montoNum = parseFloat(monto);
    const comisionPlataforma = montoNum * 0.05; // 5%
    
    let comisionPasarela;
    switch (metodoPago) {
      case 'stripe':
        comisionPasarela = montoNum * 0.036; // 3.6%
        break;
      case 'mercadopago':
        comisionPasarela = montoNum * 0.042; // 4.2%
        break;
      default:
        comisionPasarela = montoNum * 0.04; // 4% por defecto
    }

    const totalComisiones = comisionPlataforma + comisionPasarela;
    const montoOferente = montoNum - totalComisiones;

    res.json({
      monto: montoNum,
      comisiones: {
        plataforma: Math.round(comisionPlataforma * 100) / 100,
        pasarela: Math.round(comisionPasarela * 100) / 100,
        total: Math.round(totalComisiones * 100) / 100
      },
      montoOferente: Math.round(montoOferente * 100) / 100,
      metodoPago: metodoPago || 'generico'
    });

  } catch (error) {
    next(error);
  }
};

module.exports = {
  procesarPagoSimulado,
  obtenerEstadoPagoController,
  simularWebhookController,
  obtenerHistorialPagos,
  generarReporteVentasController,
  obtenerMetodosPago,
  calcularComisiones
};