// Controlador de Oferentes
const { obtenerDB } = require('../utils/database');
const { ObjectId } = require('mongodb');
// Función para crear errores personalizados
const crearError = (tipo, mensaje, status = 500) => {
  const error = new Error(mensaje);
  error.type = tipo;
  error.status = status;
  return error;
};
// Funciones auxiliares para archivos
const obtenerInfoArchivo = (archivo) => {
  if (!archivo) return null;
  return {
    nombre: archivo.filename || 'archivo_simulado.jpg',
    url: `/uploads/simulado/${Date.now()}.jpg`,
    tamaño: 1024
  };
};

const procesarArchivos = (archivos) => {
  if (!archivos || archivos.length === 0) return [];
  return archivos.map(archivo => obtenerInfoArchivo(archivo));
};

// Listar oferentes
const listarOferentes = async (req, res, next) => {
  try {
    const db = obtenerDB();
    const { page = 1, limit = 10, estado, tipoOferente, ubicacion } = req.query;
    
    // Construir filtros
    const filtros = {};
    if (estado) filtros.estado = estado;
    if (tipoOferente) filtros.tipoOferente = tipoOferente;
    if (ubicacion) filtros['ubicacion.estado'] = new RegExp(ubicacion, 'i');

    // Calcular paginación
    const skip = (page - 1) * limit;
    
    // Obtener oferentes
    const oferentes = await db.collection('oferentes')
      .find(filtros, {
        projection: {
          'datosBancarios': 0, // No incluir datos bancarios en listados
          'documentos': 0 // No incluir documentos en listados
        }
      })
      .sort({ fechaRegistro: -1 })
      .skip(skip)
      .limit(parseInt(limit))
      .toArray();

    // Contar total
    const total = await db.collection('oferentes').countDocuments(filtros);

    res.json({
      oferentes,
      paginacion: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    next(error);
  }
};

// Obtener oferente específico
const obtenerOferente = async (req, res, next) => {
  try {
    const { id } = req.params;
    const db = obtenerDB();

    const oferente = await db.collection('oferentes').findOne(
      { _id: new ObjectId(id) },
      {
        projection: {
          'datosBancarios.numeroCuenta': 0,
          'datosBancarios.clabe': 0 // Ocultar datos bancarios sensibles
        }
      }
    );

    if (!oferente) {
      throw crearError('not_found', 'Oferente no encontrado', 404);
    }

    // Si no es el propietario o admin, ocultar más información
    if (req.usuario.tipo !== 'administrador' && 
        oferente.datosPersonales.correo !== req.usuario.email) {
      delete oferente.documentos;
      delete oferente.datosBancarios;
    }

    res.json({ oferente });

  } catch (error) {
    next(error);
  }
};

// Crear oferente
const crearOferente = async (req, res, next) => {
  try {
    const db = obtenerDB();
    const datosOferente = req.body;

    // Verificar que el usuario no tenga ya un perfil de oferente
    const oferenteExistente = await db.collection('oferentes').findOne({
      'datosPersonales.correo': req.usuario.email
    });

    if (oferenteExistente) {
      throw crearError('conflict', 'Ya tienes un perfil de oferente registrado', 409);
    }

    // Verificar que el subdominio no esté en uso
    const subdominioExistente = await db.collection('oferentes').findOne({
      'micrositio.subdominio': datosOferente.micrositio.subdominio
    });

    if (subdominioExistente) {
      throw crearError('conflict', 'El subdominio ya está en uso', 409);
    }

    // Procesar archivos subidos
    const archivosInfo = {};
    if (req.files) {
      if (req.files.logo) archivosInfo.logo = obtenerInfoArchivo(req.files.logo[0]);
      if (req.files.imagenPortada) archivosInfo.imagenPortada = obtenerInfoArchivo(req.files.imagenPortada[0]);
      if (req.files.ine) archivosInfo.ine = obtenerInfoArchivo(req.files.ine[0]);
      if (req.files.constanciaFiscal) archivosInfo.constanciaFiscal = obtenerInfoArchivo(req.files.constanciaFiscal[0]);
      if (req.files.constanciaComunitaria) archivosInfo.constanciaComunitaria = obtenerInfoArchivo(req.files.constanciaComunitaria[0]);
    }

    // Crear oferente
    const nuevoOferente = {
      ...datosOferente,
      micrositio: {
        ...datosOferente.micrositio,
        url: `${datosOferente.micrositio.subdominio}.mexicoprofundo.mx`,
        activo: false, // Requiere aprobación
        fechaCreacion: new Date()
      },
      configuracion: {
        ...datosOferente.configuracion,
        logo: archivosInfo.logo?.url || null,
        imagenPortada: archivosInfo.imagenPortada?.url || null
      },
      documentos: {
        ine: {
          url: archivosInfo.ine?.url || null,
          verificado: false,
          fechaVerificacion: null
        },
        constanciaFiscal: {
          url: archivosInfo.constanciaFiscal?.url || null,
          verificado: false,
          fechaVerificacion: null
        },
        ...(archivosInfo.constanciaComunitaria && {
          constanciaComunitaria: {
            url: archivosInfo.constanciaComunitaria.url,
            verificado: false,
            fechaVerificacion: null
          }
        })
      },
      estado: 'pendiente', // Requiere aprobación administrativa
      fechaRegistro: new Date(),
      fechaUltimaActualizacion: new Date()
    };

    const resultado = await db.collection('oferentes').insertOne(nuevoOferente);

    // Crear micrositio automáticamente
    const micrositio = {
      oferenteId: resultado.insertedId,
      configuracion: {
        subdominio: datosOferente.micrositio.subdominio,
        titulo: `${datosOferente.datosPersonales.nombreComercial} - México Profundo`,
        descripcion: `Productos y servicios de ${datosOferente.datosPersonales.nombreComercial}`,
        logo: archivosInfo.logo?.url || null,
        imagenPortada: archivosInfo.imagenPortada?.url || null,
        colores: datosOferente.configuracion?.coloresTema || {
          primario: '#8B4513',
          secundario: '#D2691E',
          acento: '#FF6347'
        }
      },
      contenido: {
        sobreNosotros: `Bienvenido a ${datosOferente.datosPersonales.nombreComercial}`,
        historia: '',
        mision: '',
        vision: '',
        valores: []
      },
      secciones: {
        productos: true,
        servicios: false,
        galeria: false,
        contacto: true,
        testimonios: false,
        blog: false
      },
      estadisticas: {
        visitas: 0,
        visitasUnicas: 0,
        tiempoPromedio: 0,
        tasaRebote: 0
      },
      estado: 'inactivo', // Se activa cuando se apruebe el oferente
      fechaCreacion: new Date(),
      fechaUltimaActualizacion: new Date()
    };

    await db.collection('micrositios').insertOne(micrositio);

    // Actualizar tipo de usuario a oferente
    await db.collection('usuarios').updateOne(
      { _id: new ObjectId(req.usuario.id) },
      { $set: { tipo: 'oferente' } }
    );

    // Registrar en logs
    await db.collection('logs').insertOne({
      tipo: 'oferente',
      usuarioId: new ObjectId(req.usuario.id),
      accion: 'registro_oferente',
      detalles: {
        oferenteId: resultado.insertedId,
        tipoOferente: datosOferente.tipoOferente,
        nombreComercial: datosOferente.datosPersonales.nombreComercial
      },
      ip: req.ip,
      userAgent: req.get('User-Agent'),
      fecha: new Date(),
      nivel: 'info'
    });

    res.status(201).json({
      message: 'Oferente registrado exitosamente. Pendiente de aprobación.',
      oferente: {
        id: resultado.insertedId,
        nombreComercial: datosOferente.datosPersonales.nombreComercial,
        subdominio: datosOferente.micrositio.subdominio,
        estado: 'pendiente'
      }
    });

  } catch (error) {
    next(error);
  }
};

// Actualizar oferente
const actualizarOferente = async (req, res, next) => {
  try {
    const { id } = req.params;
    const db = obtenerDB();
    const actualizaciones = req.body;

    // Verificar que el oferente existe
    const oferente = await db.collection('oferentes').findOne({ _id: new ObjectId(id) });
    
    if (!oferente) {
      throw crearError('not_found', 'Oferente no encontrado', 404);
    }

    // Procesar archivos si se subieron
    if (req.files) {
      if (req.files.logo) {
        actualizaciones['configuracion.logo'] = obtenerInfoArchivo(req.files.logo[0]).url;
      }
      if (req.files.imagenPortada) {
        actualizaciones['configuracion.imagenPortada'] = obtenerInfoArchivo(req.files.imagenPortada[0]).url;
      }
    }

    // Agregar fecha de actualización
    actualizaciones.fechaUltimaActualizacion = new Date();

    const resultado = await db.collection('oferentes').updateOne(
      { _id: new ObjectId(id) },
      { $set: actualizaciones }
    );

    if (resultado.matchedCount === 0) {
      throw crearError('not_found', 'Oferente no encontrado', 404);
    }

    res.json({
      message: 'Oferente actualizado exitosamente'
    });

  } catch (error) {
    next(error);
  }
};

// Eliminar oferente
const eliminarOferente = async (req, res, next) => {
  try {
    const { id } = req.params;
    const db = obtenerDB();

    // Verificar que el oferente existe
    const oferente = await db.collection('oferentes').findOne({ _id: new ObjectId(id) });
    
    if (!oferente) {
      throw crearError('not_found', 'Oferente no encontrado', 404);
    }

    // Cambiar estado a eliminado en lugar de eliminar físicamente
    await db.collection('oferentes').updateOne(
      { _id: new ObjectId(id) },
      { 
        $set: { 
          estado: 'eliminado',
          fechaEliminacion: new Date()
        }
      }
    );

    // Desactivar micrositio
    await db.collection('micrositios').updateOne(
      { oferenteId: new ObjectId(id) },
      { $set: { estado: 'inactivo' } }
    );

    // Desactivar productos
    await db.collection('productos').updateMany(
      { oferenteId: new ObjectId(id) },
      { $set: { estado: 'pausado' } }
    );

    res.json({
      message: 'Oferente eliminado exitosamente'
    });

  } catch (error) {
    next(error);
  }
};

// Obtener estadísticas del oferente
const obtenerEstadisticas = async (req, res, next) => {
  try {
    const { id } = req.params;
    const db = obtenerDB();

    // Verificar que el oferente existe
    const oferente = await db.collection('oferentes').findOne({ _id: new ObjectId(id) });
    
    if (!oferente) {
      throw crearError('not_found', 'Oferente no encontrado', 404);
    }

    // Obtener estadísticas
    const [productos, pedidos, transacciones, micrositio] = await Promise.all([
      // Contar productos
      db.collection('productos').countDocuments({ oferenteId: new ObjectId(id) }),
      
      // Contar pedidos
      db.collection('pedidos').countDocuments({ oferenteId: new ObjectId(id) }),
      
      // Sumar ventas
      db.collection('transacciones').aggregate([
        { $match: { oferenteId: new ObjectId(id), estado: 'completado' } },
        { $group: { _id: null, totalVentas: { $sum: '$monto' }, numeroTransacciones: { $sum: 1 } } }
      ]).toArray(),
      
      // Estadísticas del micrositio
      db.collection('micrositios').findOne({ oferenteId: new ObjectId(id) })
    ]);

    const ventasData = transacciones[0] || { totalVentas: 0, numeroTransacciones: 0 };

    const estadisticas = {
      productos: productos,
      pedidos: pedidos,
      ventas: {
        total: ventasData.totalVentas,
        numeroTransacciones: ventasData.numeroTransacciones,
        promedio: ventasData.numeroTransacciones > 0 ? ventasData.totalVentas / ventasData.numeroTransacciones : 0
      },
      micrositio: {
        visitas: micrositio?.estadisticas?.visitas || 0,
        visitasUnicas: micrositio?.estadisticas?.visitasUnicas || 0,
        tiempoPromedio: micrositio?.estadisticas?.tiempoPromedio || 0
      }
    };

    res.json({ estadisticas });

  } catch (error) {
    next(error);
  }
};

module.exports = {
  listarOferentes,
  obtenerOferente,
  crearOferente,
  actualizarOferente,
  eliminarOferente,
  obtenerEstadisticas
};