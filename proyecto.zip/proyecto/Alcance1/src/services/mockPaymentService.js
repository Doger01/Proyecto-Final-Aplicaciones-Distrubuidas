// Servicio Simulado de Pagos - Solo para Proyecto Escolar
const { obtenerDB } = require('../utils/database');
const { ObjectId } = require('mongodb');

// Configuración de simulación
const PAYMENT_CONFIG = {
  successRate: parseFloat(process.env.PAYMENT_SUCCESS_RATE) || 0.95, // 95% de éxito
  processingDelay: parseInt(process.env.SIMULATE_PAYMENT_DELAY) || 2000, // 2 segundos
  mockMode: process.env.MOCK_PAYMENTS === 'true'
};

// Simular delay de procesamiento
const simularDelay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// Generar ID de transacción simulado
const generarTransactionId = (metodo) => {
  const timestamp = Date.now();
  const random = Math.random().toString(36).substring(2, 8);
  const prefijo = metodo === 'stripe' ? 'pi_' : metodo === 'mercadopago' ? 'mp_' : 'sim_';
  return `${prefijo}${timestamp}_${random}`;
};

// Simular procesamiento de pago con Stripe
const procesarPagoStripe = async (datosPago) => {
  await simularDelay(PAYMENT_CONFIG.processingDelay);
  
  const exitoso = Math.random() < PAYMENT_CONFIG.successRate;
  const transactionId = generarTransactionId('stripe');
  
  if (!exitoso) {
    throw new Error('Pago rechazado por el banco (simulado)');
  }
  
  return {
    id: transactionId,
    status: 'succeeded',
    amount: datosPago.amount,
    currency: datosPago.currency || 'mxn',
    payment_method: 'card',
    created: Math.floor(Date.now() / 1000),
    metadata: datosPago.metadata || {}
  };
};

// Simular procesamiento de pago con MercadoPago
const procesarPagoMercadoPago = async (datosPago) => {
  await simularDelay(PAYMENT_CONFIG.processingDelay);
  
  const exitoso = Math.random() < PAYMENT_CONFIG.successRate;
  const transactionId = generarTransactionId('mercadopago');
  
  if (!exitoso) {
    throw new Error('Pago rechazado (simulado)');
  }
  
  return {
    id: transactionId,
    status: 'approved',
    status_detail: 'accredited',
    transaction_amount: datosPago.transaction_amount,
    currency_id: datosPago.currency_id || 'MXN',
    payment_method_id: 'visa',
    date_created: new Date().toISOString(),
    metadata: datosPago.metadata || {}
  };
};

// Procesar pago principal
const procesarPago = async (pedidoId, metodoPago, datosPago) => {
  try {
    const db = obtenerDB();
    
    // Obtener información del pedido
    const pedido = await db.collection('pedidos').findOne({ _id: new ObjectId(pedidoId) });
    
    if (!pedido) {
      throw new Error('Pedido no encontrado');
    }
    
    if (pedido.pago.estado === 'completado') {
      throw new Error('El pedido ya ha sido pagado');
    }
    
    console.log(`Procesando pago simulado para pedido ${pedidoId} con ${metodoPago}`);
    
    let resultadoPago;
    
    // Procesar según el método de pago
    switch (metodoPago) {
      case 'stripe':
        resultadoPago = await procesarPagoStripe({
          amount: Math.round(pedido.totales.total * 100), // Stripe usa centavos
          currency: 'mxn',
          metadata: {
            pedido_id: pedidoId.toString(),
            oferente_id: pedido.oferenteId.toString()
          }
        });
        break;
        
      case 'mercadopago':
        resultadoPago = await procesarPagoMercadoPago({
          transaction_amount: pedido.totales.total,
          currency_id: 'MXN',
          metadata: {
            pedido_id: pedidoId.toString(),
            oferente_id: pedido.oferenteId.toString()
          }
        });
        break;
        
      default:
        throw new Error('Método de pago no soportado');
    }
    
    // Calcular comisiones
    const comisionPlataforma = pedido.totales.total * 0.05; // 5%
    const comisionPasarela = pedido.totales.total * (metodoPago === 'stripe' ? 0.036 : 0.042); // 3.6% Stripe, 4.2% MercadoPago
    const montoOferente = pedido.totales.total - comisionPlataforma - comisionPasarela;
    
    // Actualizar estado del pedido
    await db.collection('pedidos').updateOne(
      { _id: new ObjectId(pedidoId) },
      {
        $set: {
          'pago.transaccionId': resultadoPago.id,
          'pago.estado': 'completado',
          'pago.fechaPago': new Date(),
          'pago.metodo': metodoPago,
          'pago.comision.plataforma': comisionPlataforma,
          'pago.comision.pasarela': comisionPasarela,
          estado: 'confirmado',
          fechaUltimaActualizacion: new Date()
        },
        $push: {
          historialEstados: {
            estado: 'confirmado',
            fecha: new Date(),
            comentario: `Pago procesado exitosamente con ${metodoPago}`
          }
        }
      }
    );
    
    // Crear registro de transacción
    const transaccion = {
      pedidoId: new ObjectId(pedidoId),
      oferenteId: pedido.oferenteId,
      tipo: 'venta',
      monto: pedido.totales.total,
      moneda: 'MXN',
      pasarelaPago: {
        proveedor: metodoPago,
        transaccionId: resultadoPago.id,
        comision: comisionPasarela
      },
      distribucion: {
        oferente: montoOferente,
        plataforma: comisionPlataforma,
        impuestos: 0
      },
      estado: 'completado',
      fechaTransaccion: new Date(),
      fechaLiberacion: new Date(Date.now() + 24 * 60 * 60 * 1000), // Liberar en 24 horas
      metadatos: {
        pedidoNumero: pedido.numeroPedido,
        simulado: true,
        metodoPago: metodoPago
      }
    };
    
    await db.collection('transacciones').insertOne(transaccion);
    
    // Registrar en logs
    await db.collection('logs').insertOne({
      tipo: 'transaccion',
      usuarioId: pedido.compradorId,
      accion: 'pago_procesado',
      detalles: {
        pedidoId: pedidoId,
        transaccionId: resultadoPago.id,
        monto: pedido.totales.total,
        metodoPago: metodoPago,
        simulado: true
      },
      fecha: new Date(),
      nivel: 'info'
    });
    
    console.log(`Pago simulado completado: ${resultadoPago.id}`);
    
    return {
      success: true,
      transaccionId: resultadoPago.id,
      estado: 'completado',
      monto: pedido.totales.total,
      metodoPago: metodoPago,
      comisiones: {
        plataforma: comisionPlataforma,
        pasarela: comisionPasarela
      },
      simulado: true
    };
    
  } catch (error) {
    console.error('Error procesando pago simulado:', error);
    
    // Actualizar pedido con error
    if (pedidoId) {
      const db = obtenerDB();
      await db.collection('pedidos').updateOne(
        { _id: new ObjectId(pedidoId) },
        {
          $set: {
            'pago.estado': 'fallido',
            'pago.fechaPago': new Date(),
            'pago.error': error.message,
            fechaUltimaActualizacion: new Date()
          },
          $push: {
            historialEstados: {
              estado: 'pago_fallido',
              fecha: new Date(),
              comentario: `Error en pago: ${error.message}`
            }
          }
        }
      );
    }
    
    throw error;
  }
};

// Obtener estado de pago
const obtenerEstadoPago = async (transaccionId) => {
  try {
    const db = obtenerDB();
    
    const transaccion = await db.collection('transacciones').findOne({
      'pasarelaPago.transaccionId': transaccionId
    });
    
    if (!transaccion) {
      throw new Error('Transacción no encontrada');
    }
    
    return {
      id: transaccionId,
      estado: transaccion.estado,
      monto: transaccion.monto,
      fecha: transaccion.fechaTransaccion,
      metodoPago: transaccion.pasarelaPago.proveedor,
      simulado: true
    };
    
  } catch (error) {
    console.error('Error obteniendo estado de pago:', error);
    throw error;
  }
};

// Simular webhook de pago
const simularWebhook = async (transaccionId, nuevoEstado) => {
  try {
    const db = obtenerDB();
    
    // Actualizar estado de la transacción
    await db.collection('transacciones').updateOne(
      { 'pasarelaPago.transaccionId': transaccionId },
      { 
        $set: { 
          estado: nuevoEstado,
          fechaUltimaActualizacion: new Date()
        }
      }
    );
    
    // Registrar webhook simulado
    await db.collection('logs').insertOne({
      tipo: 'webhook',
      usuarioId: null,
      accion: 'webhook_simulado',
      detalles: {
        transaccionId: transaccionId,
        nuevoEstado: nuevoEstado,
        simulado: true
      },
      fecha: new Date(),
      nivel: 'info'
    });
    
    console.log(`Webhook simulado procesado: ${transaccionId} -> ${nuevoEstado}`);
    
    return { success: true };
    
  } catch (error) {
    console.error('Error procesando webhook simulado:', error);
    throw error;
  }
};

// Generar reporte de ventas
const generarReporteVentas = async (oferenteId, fechaInicio, fechaFin) => {
  try {
    const db = obtenerDB();
    
    const filtros = {
      oferenteId: new ObjectId(oferenteId),
      estado: 'completado'
    };
    
    if (fechaInicio || fechaFin) {
      filtros.fechaTransaccion = {};
      if (fechaInicio) filtros.fechaTransaccion.$gte = new Date(fechaInicio);
      if (fechaFin) filtros.fechaTransaccion.$lte = new Date(fechaFin);
    }
    
    const transacciones = await db.collection('transacciones').aggregate([
      { $match: filtros },
      {
        $group: {
          _id: null,
          totalVentas: { $sum: '$monto' },
          totalComisiones: { $sum: '$distribucion.plataforma' },
          totalOferente: { $sum: '$distribucion.oferente' },
          numeroTransacciones: { $sum: 1 }
        }
      }
    ]).toArray();
    
    const resultado = transacciones[0] || {
      totalVentas: 0,
      totalComisiones: 0,
      totalOferente: 0,
      numeroTransacciones: 0
    };
    
    return {
      ...resultado,
      promedioVenta: resultado.numeroTransacciones > 0 ? resultado.totalVentas / resultado.numeroTransacciones : 0,
      simulado: true
    };
    
  } catch (error) {
    console.error('Error generando reporte de ventas:', error);
    throw error;
  }
};

module.exports = {
  procesarPago,
  obtenerEstadoPago,
  simularWebhook,
  generarReporteVentas,
  PAYMENT_CONFIG
};