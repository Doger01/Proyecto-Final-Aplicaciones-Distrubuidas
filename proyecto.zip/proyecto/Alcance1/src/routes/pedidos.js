// Rutas de Pedidos
const express = require('express');
const router = express.Router();

// Placeholder para controlador de pedidos
const pedidosController = {
  listarPedidos: (req, res) => {
    res.json({
      message: 'Endpoint de pedidos en desarrollo',
      pedidos: [],
      paginacion: { page: 1, limit: 10, total: 0, pages: 0 }
    });
  },
  
  obtenerPedido: (req, res) => {
    res.json({
      message: 'Endpoint de pedido específico en desarrollo',
      pedido: null
    });
  },
  
  crearPedido: (req, res) => {
    res.status(201).json({
      message: 'Endpoint de crear pedido en desarrollo'
    });
  },
  
  actualizarEstadoPedido: (req, res) => {
    res.json({
      message: 'Endpoint de actualizar estado de pedido en desarrollo'
    });
  }
};

const { verificarToken, verificarComprador, verificarOferente } = require('../middleware/auth');

// Rutas protegidas
router.get('/', verificarToken, pedidosController.listarPedidos);
router.get('/:id', verificarToken, pedidosController.obtenerPedido);
router.post('/', verificarToken, verificarComprador, pedidosController.crearPedido);
router.put('/:id/status', verificarToken, verificarOferente, pedidosController.actualizarEstadoPedido);

module.exports = router;