// Rutas de Pagos Simulados
const express = require('express');
const router = express.Router();
const Joi = require('joi');

// Importar controladores y middleware
const {
  procesarPagoSimulado,
  obtenerEstadoPagoController,
  simularWebhookController,
  obtenerHistorialPagos,
  generarReporteVentasController,
  obtenerMetodosPago,
  calcularComisiones
} = require('../controllers/pagosController');

const { verificarToken, verificarOferente, verificarComprador } = require('../middleware/auth');
const { validar, validarParametros, validarQuery } = require('../middleware/validation');

// Esquemas de validación
const esquemaProcesarPago = Joi.object({
  pedidoId: Joi.string().pattern(/^[0-9a-fA-F]{24}$/).required()
    .messages({
      'string.pattern.base': 'El ID del pedido debe ser un ObjectId válido',
      'any.required': 'El ID del pedido es obligatorio'
    }),
  metodoPago: Joi.string().valid('stripe', 'mercadopago').required()
    .messages({
      'any.only': 'El método de pago debe ser stripe o mercadopago',
      'any.required': 'El método de pago es obligatorio'
    }),
  datosPago: Joi.object({
    numeroTarjeta: Joi.string().optional(),
    cvv: Joi.string().optional(),
    fechaExpiracion: Joi.string().optional(),
    nombreTitular: Joi.string().optional()
  }).optional()
});

const esquemaWebhook = Joi.object({
  transaccionId: Joi.string().required()
    .messages({
      'any.required': 'El ID de transacción es obligatorio'
    }),
  nuevoEstado: Joi.string().valid('completado', 'fallido', 'reembolsado').required()
    .messages({
      'any.only': 'El estado debe ser: completado, fallido o reembolsado',
      'any.required': 'El nuevo estado es obligatorio'
    })
});

const esquemaCalcularComisiones = Joi.object({
  monto: Joi.number().positive().required()
    .messages({
      'number.positive': 'El monto debe ser mayor a 0',
      'any.required': 'El monto es obligatorio'
    }),
  metodoPago: Joi.string().valid('stripe', 'mercadopago').optional()
});

const esquemaReporteVentas = Joi.object({
  fechaInicio: Joi.date().iso().optional(),
  fechaFin: Joi.date().iso().min(Joi.ref('fechaInicio')).optional()
    .messages({
      'date.min': 'La fecha fin debe ser posterior a la fecha inicio'
    })
});

const esquemaPaginacion = Joi.object({
  page: Joi.number().integer().min(1).default(1),
  limit: Joi.number().integer().min(1).max(50).default(10)
});

// Rutas públicas

// GET /api/pagos/metodos - Obtener métodos de pago disponibles
router.get('/metodos', obtenerMetodosPago);

// GET /api/pagos/calcular-comisiones - Calcular comisiones para un monto
router.get('/calcular-comisiones', validarQuery(esquemaCalcularComisiones), calcularComisiones);

// Rutas protegidas para compradores

// POST /api/pagos/procesar - Procesar pago simulado
router.post('/procesar',
  verificarToken,
  verificarComprador,
  validar(esquemaProcesarPago),
  procesarPagoSimulado
);

// GET /api/pagos/historial - Obtener historial de pagos del usuario
router.get('/historial',
  verificarToken,
  verificarComprador,
  validarQuery(esquemaPaginacion),
  obtenerHistorialPagos
);

// Rutas protegidas para oferentes

// GET /api/pagos/reporte - Generar reporte de ventas
router.get('/reporte',
  verificarToken,
  verificarOferente,
  validarQuery(esquemaReporteVentas),
  generarReporteVentasController
);

// Rutas públicas para consulta

// GET /api/pagos/:transaccionId/status - Obtener estado de pago
router.get('/:transaccionId/status',
  validarParametros(Joi.object({
    transaccionId: Joi.string().required()
  })),
  obtenerEstadoPagoController
);

// Rutas de desarrollo (solo en modo desarrollo)

// POST /api/pagos/webhook-simulado - Simular webhook (solo desarrollo)
router.post('/webhook-simulado',
  validar(esquemaWebhook),
  simularWebhookController
);

module.exports = router;