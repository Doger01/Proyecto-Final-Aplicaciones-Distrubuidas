// Rutas de Oferentes
const express = require('express');
const router = express.Router();

// Importar controladores y middleware
const {
  listarOferentes,
  obtenerOferente,
  crearOferente,
  actualizarOferente,
  eliminarOferente,
  obtenerEstadisticas
} = require('../controllers/oferentesController');

const { verificarToken, verificarOferente, verificarPropietario, verificarAdmin } = require('../middleware/auth');
const { validar, validarParametros, validarQuery, esquemaOferente, esquemaId, esquemaPaginacion } = require('../middleware/validation');
const { subirArchivosOferente, manejarErroresUpload } = require('../middleware/upload');

// Rutas públicas

// GET /api/oferentes - Listar oferentes (público, datos limitados)
router.get('/', validarQuery(esquemaPaginacion), listarOferentes);

// GET /api/oferentes/:id - Obtener oferente específico
router.get('/:id', validarParametros(esquemaId), obtenerOferente);

// Rutas protegidas

// POST /api/oferentes - Crear nuevo oferente (requiere autenticación)
router.post('/', 
  verificarToken,
  subirArchivosOferente,
  manejarErroresUpload,
  validar(esquemaOferente),
  crearOferente
);

// PUT /api/oferentes/:id - Actualizar oferente (solo propietario o admin)
router.put('/:id',
  verificarToken,
  validarParametros(esquemaId),
  verificarPropietario,
  subirArchivosOferente,
  manejarErroresUpload,
  actualizarOferente
);

// DELETE /api/oferentes/:id - Eliminar oferente (solo propietario o admin)
router.delete('/:id',
  verificarToken,
  validarParametros(esquemaId),
  verificarPropietario,
  eliminarOferente
);

// GET /api/oferentes/:id/stats - Obtener estadísticas del oferente
router.get('/:id/stats',
  verificarToken,
  validarParametros(esquemaId),
  verificarPropietario,
  obtenerEstadisticas
);

module.exports = router;