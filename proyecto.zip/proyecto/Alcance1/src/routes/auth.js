// Rutas de Autenticación
const express = require('express');
const router = express.Router();

// Importar controladores y middleware
const {
  registrarUsuario,
  iniciarSesion,
  obtenerPerfil,
  actualizarPerfil,
  cambiarPassword,
  renovarToken,
  cerrarSesion
} = require('../controllers/authController');

const { verificarToken } = require('../middleware/auth');
const { validar, esquemaRegistroUsuario, esquemaLogin } = require('../middleware/validation');
const Joi = require('joi');

// Esquemas de validación adicionales
const esquemaActualizarPerfil = Joi.object({
  nombre: Joi.string().min(2).max(50).required(),
  apellidos: Joi.string().min(2).max(100).required(),
  telefono: Joi.string().pattern(/^\+52\s?[0-9]{3}\s?[0-9]{3}\s?[0-9]{4}$/).required(),
  preferencias: Joi.object({
    idioma: Joi.string().valid('es', 'en', 'maya', 'fr', 'zh').default('es'),
    moneda: Joi.string().valid('MXN', 'USD').default('MXN'),
    notificaciones: Joi.object({
      email: Joi.boolean().default(true),
      sms: Joi.boolean().default(false),
      push: Joi.boolean().default(true)
    }).default()
  }).default()
});

const esquemaCambiarPassword = Joi.object({
  passwordActual: Joi.string().required()
    .messages({
      'any.required': 'La contraseña actual es obligatoria'
    }),
  passwordNueva: Joi.string().min(6).max(100).required()
    .messages({
      'string.min': 'La nueva contraseña debe tener al menos 6 caracteres',
      'string.max': 'La nueva contraseña no puede exceder 100 caracteres',
      'any.required': 'La nueva contraseña es obligatoria'
    })
});

const esquemaRenovarToken = Joi.object({
  refreshToken: Joi.string().required()
    .messages({
      'any.required': 'El refresh token es obligatorio'
    })
});

// Rutas públicas (no requieren autenticación)

// POST /api/auth/register - Registrar nuevo usuario
router.post('/register', validar(esquemaRegistroUsuario), registrarUsuario);

// POST /api/auth/login - Iniciar sesión
router.post('/login', validar(esquemaLogin), iniciarSesion);

// POST /api/auth/refresh - Renovar token
router.post('/refresh', validar(esquemaRenovarToken), renovarToken);

// Rutas protegidas (requieren autenticación)

// GET /api/auth/profile - Obtener perfil del usuario
router.get('/profile', verificarToken, obtenerPerfil);

// PUT /api/auth/profile - Actualizar perfil del usuario
router.put('/profile', verificarToken, validar(esquemaActualizarPerfil), actualizarPerfil);

// PUT /api/auth/password - Cambiar contraseña
router.put('/password', verificarToken, validar(esquemaCambiarPassword), cambiarPassword);

// POST /api/auth/logout - Cerrar sesión
router.post('/logout', verificarToken, cerrarSesion);

module.exports = router;