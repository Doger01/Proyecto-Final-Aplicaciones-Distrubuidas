// Rutas de Productos
const express = require('express');
const router = express.Router();

// Placeholder para controlador de productos
const productosController = {
  listarProductos: (req, res) => {
    res.json({
      message: 'Endpoint de productos en desarrollo',
      productos: [],
      paginacion: { page: 1, limit: 10, total: 0, pages: 0 }
    });
  },
  
  obtenerProducto: (req, res) => {
    res.json({
      message: 'Endpoint de producto específico en desarrollo',
      producto: null
    });
  },
  
  crearProducto: (req, res) => {
    res.status(201).json({
      message: 'Endpoint de crear producto en desarrollo'
    });
  },
  
  actualizarProducto: (req, res) => {
    res.json({
      message: 'Endpoint de actualizar producto en desarrollo'
    });
  },
  
  eliminarProducto: (req, res) => {
    res.json({
      message: 'Endpoint de eliminar producto en desarrollo'
    });
  },
  
  buscarProductos: (req, res) => {
    res.json({
      message: 'Endpoint de búsqueda de productos en desarrollo',
      productos: [],
      termino: req.query.q || ''
    });
  }
};

const { verificarToken, verificarOferente } = require('../middleware/auth');

// Rutas públicas
router.get('/', productosController.listarProductos);
router.get('/search', productosController.buscarProductos);
router.get('/:id', productosController.obtenerProducto);

// Rutas protegidas
router.post('/', verificarToken, verificarOferente, productosController.crearProducto);
router.put('/:id', verificarToken, verificarOferente, productosController.actualizarProducto);
router.delete('/:id', verificarToken, verificarOferente, productosController.eliminarProducto);

module.exports = router;