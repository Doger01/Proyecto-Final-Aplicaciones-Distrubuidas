// Configuración de Base de Datos MongoDB
const { MongoClient } = require('mongodb');

const uri = process.env.MONGODB_URI || "mongodb+srv://legmafer_db_user:ZQmLpt0YnguOlShf@cluster0.kp7b9yo.mongodb.net/?appName=Cluster0";
const dbName = process.env.DB_NAME || "mexicoProfundo";

let client;
let db;

// Configuración del cliente MongoDB
const clientOptions = {
  maxPoolSize: 10,
  serverSelectionTimeoutMS: 5000,
  socketTimeoutMS: 45000,
  retryWrites: true
};

// Función para conectar a MongoDB
async function conectarMongoDB() {
  try {
    if (!client) {
      console.log('Conectando a MongoDB Atlas...');
      client = new MongoClient(uri, clientOptions);
      await client.connect();
      
      // Verificar conexión
      await client.db("admin").command({ ping: 1 });
      console.log('Conexión exitosa a MongoDB Atlas');
      
      // Seleccionar base de datos
      db = client.db(dbName);
    }
    
    return db;
  } catch (error) {
    console.error('Error conectando a MongoDB:', error);
    throw error;
  }
}

// Función para obtener la base de datos
function obtenerDB() {
  if (!db) {
    throw new Error('Base de datos no inicializada. Ejecuta conectarMongoDB() primero.');
  }
  return db;
}

// Función para cerrar conexión
async function cerrarConexion() {
  try {
    if (client) {
      await client.close();
      console.log('Conexión a MongoDB cerrada');
      client = null;
      db = null;
    }
  } catch (error) {
    console.error('Error cerrando conexión:', error);
  }
}

// Función para verificar el estado de la conexión
async function verificarConexion() {
  try {
    if (!client) {
      return false;
    }
    
    await client.db("admin").command({ ping: 1 });
    return true;
  } catch (error) {
    console.error('Conexión inactiva:', error.message);
    return false;
  }
}

// Función para obtener estadísticas de la base de datos
async function obtenerEstadisticas() {
  try {
    const db = obtenerDB();
    const stats = await db.stats();
    
    return {
      nombre: stats.db,
      colecciones: stats.collections,
      documentos: stats.objects,
      tamaño: {
        datos: Math.round(stats.dataSize / 1024 / 1024 * 100) / 100 + ' MB',
        indices: Math.round(stats.indexSize / 1024 / 1024 * 100) / 100 + ' MB',
        total: Math.round(stats.storageSize / 1024 / 1024 * 100) / 100 + ' MB'
      }
    };
  } catch (error) {
    console.error('Error obteniendo estadísticas:', error);
    throw error;
  }
}

module.exports = {
  conectarMongoDB,
  obtenerDB,
  cerrarConexion,
  verificarConexion,
  obtenerEstadisticas
};