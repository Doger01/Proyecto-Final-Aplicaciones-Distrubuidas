# México Profundo - Backend (Node.js + Express + MongoDB)

API REST enfocada en:
- Registro/validación de oferentes.
- Creación automática de micrositios (slug / URL).
- CRUD de productos/servicios.
- Autenticación JWT (rol admin / oferente).

## Requisitos
- Node.js 18+
- MongoDB local o Atlas

## Instalación
```bash
cp .env.example .env
npm install
npm run dev
```

## Endpoints principales
- `GET /api/health`
- `POST /api/auth/register` (crea usuario + perfil oferente + micrositio)
- `POST /api/auth/login`
- `GET /api/me`
- CRUD:
  - `/api/oferentes`
  - `/api/micrositios`
  - `/api/productos`

Incluye ejemplos en `docs/postman_collection.json`.
