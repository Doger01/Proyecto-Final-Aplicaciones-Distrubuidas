const express = require("express");
const helmet = require("helmet");
const cors = require("cors");
const compression = require("compression");
const morgan = require("morgan");
const rateLimit = require("express-rate-limit");

const { notFoundHandler, errorHandler } = require("./middleware/errors");

const authRoutes = require("./routes/auth.routes");
const meRoutes = require("./routes/me.routes");
const oferenteRoutes = require("./routes/oferentes.routes");
const micrositioRoutes = require("./routes/micrositios.routes");
const productoRoutes = require("./routes/productos.routes");

const app = express();

app.disable("x-powered-by");
app.use(helmet());
app.use(compression());

app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true }));

const origins = (process.env.CORS_ORIGINS || "").split(",").map((s) => s.trim()).filter(Boolean);
app.use(cors({
  origin: origins.length ? origins : true,
  credentials: true
}));

app.use(morgan("dev"));

app.use(rateLimit({
  windowMs: 60_000,
  limit: 120,
  standardHeaders: "draft-7",
  legacyHeaders: false
}));

app.get("/api/health", (req, res) => res.json({ ok: true, ts: new Date().toISOString() }));

app.use("/api/auth", authRoutes);
app.use("/api", meRoutes);
app.use("/api/oferentes", oferenteRoutes);
app.use("/api/micrositios", micrositioRoutes);
app.use("/api/productos", productoRoutes);

app.use(notFoundHandler);
app.use(errorHandler);

module.exports = app;
