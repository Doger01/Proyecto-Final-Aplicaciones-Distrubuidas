const slugify = require("slugify");

function toSlug(input) {
  return slugify(String(input || ""), {
    lower: true,
    strict: true,
    trim: true
  });
}

module.exports = { toSlug };
