const Producto = require("../models/Producto");
const Oferente = require("../models/Oferente");
const { pick } = require("../utils/pick");

async function list(req, res, next) {
  try {
    const { oferenteId, categoria, q, activo } = req.query;
    const filter = {};
    if (oferenteId) filter.oferenteId = oferenteId;
    if (categoria) filter.categoria = categoria;
    if (activo !== undefined) filter.activo = activo === "true";
    if (q) filter.titulo = { $regex: q, $options: "i" };

    const items = await Producto.find(filter).sort({ createdAt: -1 });
    res.json({ items });
  } catch (err) { next(err); }
}

async function getOne(req, res, next) {
  try {
    const item = await Producto.findById(req.params.id);
    if (!item) return res.status(404).json({ error: "NOT_FOUND" });
    res.json(item);
  } catch (err) { next(err); }
}

async function create(req, res, next) {
  try {
    const allowed = ["oferenteId", "titulo", "descripcion", "precio", "moneda", "existencias", "categoria", "etiquetas", "imagenes", "activo"];
    const data = pick(req.body, allowed);

    const oferente = await Oferente.findById(data.oferenteId);
    if (!oferente) return res.status(400).json({ error: "INVALID_OFERENTE" });

    const item = await Producto.create(data);
    res.status(201).json(item);
  } catch (err) { next(err); }
}

async function update(req, res, next) {
  try {
    const allowed = ["titulo", "descripcion", "precio", "moneda", "existencias", "categoria", "etiquetas", "imagenes", "activo"];
    const patch = pick(req.body, allowed);

    const item = await Producto.findByIdAndUpdate(req.params.id, patch, { new: true });
    if (!item) return res.status(404).json({ error: "NOT_FOUND" });
    res.json(item);
  } catch (err) { next(err); }
}

async function remove(req, res, next) {
  try {
    const item = await Producto.findByIdAndDelete(req.params.id);
    if (!item) return res.status(404).json({ error: "NOT_FOUND" });
    res.status(204).send();
  } catch (err) { next(err); }
}

module.exports = { list, getOne, create, update, remove };
