const Oferente = require("../models/Oferente");
const { pick } = require("../utils/pick");

async function list(req, res, next) {
  try {
    const { estado } = req.query;
    const filter = {};
    if (estado) filter["validacion.estado"] = estado;
    const items = await Oferente.find(filter).sort({ createdAt: -1 });
    res.json({ items });
  } catch (err) { next(err); }
}

async function getOne(req, res, next) {
  try {
    const item = await Oferente.findById(req.params.id);
    if (!item) return res.status(404).json({ error: "NOT_FOUND" });
    res.json(item);
  } catch (err) { next(err); }
}

async function update(req, res, next) {
  try {
    const allowed = [
      "nombreCompleto", "nombreComercial", "telefono", "localidad", "tipoActividad",
      "rfc", "datosBancarios", "documentos", "validacion"
    ];
    const patch = pick(req.body, allowed);

    const item = await Oferente.findByIdAndUpdate(req.params.id, patch, { new: true });
    if (!item) return res.status(404).json({ error: "NOT_FOUND" });
    res.json(item);
  } catch (err) { next(err); }
}

async function remove(req, res, next) {
  try {
    const item = await Oferente.findByIdAndDelete(req.params.id);
    if (!item) return res.status(404).json({ error: "NOT_FOUND" });
    res.status(204).send();
  } catch (err) { next(err); }
}

module.exports = { list, getOne, update, remove };
