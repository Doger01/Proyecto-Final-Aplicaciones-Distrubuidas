const Micrositio = require("../models/Micrositio");
const { pick } = require("../utils/pick");
const { toSlug } = require("../utils/slug");

async function list(req, res, next) {
  try {
    const items = await Micrositio.find().sort({ createdAt: -1 });
    res.json({ items });
  } catch (err) { next(err); }
}

async function getBySlug(req, res, next) {
  try {
    const item = await Micrositio.findOne({ slug: req.params.slug });
    if (!item) return res.status(404).json({ error: "NOT_FOUND" });
    res.json(item);
  } catch (err) { next(err); }
}

async function update(req, res, next) {
  try {
    const allowed = ["plantilla", "tema", "descripcionCorta", "logoUrl", "ubicacion", "contacto"];
    const patch = pick(req.body, allowed);

    const item = await Micrositio.findByIdAndUpdate(req.params.id, patch, { new: true });
    if (!item) return res.status(404).json({ error: "NOT_FOUND" });
    res.json(item);
  } catch (err) { next(err); }
}

// (opcional) renombrar slug
async function changeSlug(req, res, next) {
  try {
    const newSlug = toSlug(req.body.slug);
    if (!newSlug) return res.status(400).json({ error: "INVALID_SLUG" });

    const exists = await Micrositio.findOne({ slug: newSlug });
    if (exists) return res.status(409).json({ error: "SLUG_IN_USE" });

    const item = await Micrositio.findById(req.params.id);
    if (!item) return res.status(404).json({ error: "NOT_FOUND" });

    item.slug = newSlug;
    item.urlPath = `/artesano/${newSlug}`;
    await item.save();

    res.json(item);
  } catch (err) { next(err); }
}

module.exports = { list, getBySlug, update, changeSlug };
