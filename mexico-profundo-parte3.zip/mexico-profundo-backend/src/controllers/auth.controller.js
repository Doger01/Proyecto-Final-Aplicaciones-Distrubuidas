const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/User");
const Oferente = require("../models/Oferente");
const Micrositio = require("../models/Micrositio");
const { toSlug } = require("../utils/slug");

function signToken(user) {
  const payload = { sub: String(user._id), role: user.role };
  return jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: "7d" });
}

async function register(req, res, next) {
  try {
    const {
      email, password,
      nombreCompleto, nombreComercial, telefono, localidad, tipoActividad,
      rfc, datosBancarios, documentos
    } = req.body;

    const exists = await User.findOne({ email });
    if (exists) return res.status(409).json({ error: "EMAIL_IN_USE" });

    const passwordHash = await bcrypt.hash(password, 12);
    const user = await User.create({ email, passwordHash, role: "oferente" });

    const oferente = await Oferente.create({
      userId: user._id,
      nombreCompleto,
      nombreComercial,
      correo: email,
      telefono,
      localidad,
      tipoActividad,
      rfc,
      datosBancarios,
      documentos
    });

    // Micrositio: slug único
    const baseSlug = toSlug(nombreComercial || nombreCompleto);
    let slug = baseSlug || "oferente";
    let attempt = 0;
    while (await Micrositio.findOne({ slug })) {
      attempt += 1;
      slug = `${baseSlug}-${attempt}`;
    }

    const micrositio = await Micrositio.create({
      oferenteId: oferente._id,
      slug,
      urlPath: `/artesano/${slug}`,
      descripcionCorta: ""
    });

    const token = signToken(user);
    return res.status(201).json({
      token,
      user: { id: user._id, email: user.email, role: user.role },
      oferente,
      micrositio
    });
  } catch (err) {
    return next(err);
  }
}

async function login(req, res, next) {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user || !user.isActive) return res.status(401).json({ error: "INVALID_CREDENTIALS" });

    const ok = await bcrypt.compare(password, user.passwordHash);
    if (!ok) return res.status(401).json({ error: "INVALID_CREDENTIALS" });

    const token = signToken(user);
    return res.json({ token, user: { id: user._id, email: user.email, role: user.role } });
  } catch (err) {
    return next(err);
  }
}

module.exports = { register, login };
