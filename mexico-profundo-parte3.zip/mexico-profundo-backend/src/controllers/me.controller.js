const User = require("../models/User");
const Oferente = require("../models/Oferente");
const Micrositio = require("../models/Micrositio");

async function me(req, res, next) {
  try {
    const userId = req.user.sub;
    const user = await User.findById(userId).select("_id email role isActive createdAt");
    if (!user) return res.status(404).json({ error: "USER_NOT_FOUND" });

    const oferente = await Oferente.findOne({ userId: user._id });
    const micrositio = oferente ? await Micrositio.findOne({ oferenteId: oferente._id }) : null;

    return res.json({ user, oferente, micrositio });
  } catch (err) {
    return next(err);
  }
}

module.exports = { me };
