const mongoose = require("mongoose");

const OferenteSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, unique: true },
  nombreCompleto: { type: String, required: true, trim: true },
  nombreComercial: { type: String, required: true, trim: true },
  correo: { type: String, required: true, trim: true, lowercase: true },
  telefono: { type: String, required: true, trim: true },
  localidad: { type: String, required: true, trim: true },
  tipoActividad: { type: String, enum: ["artesania", "turismo", "cooperativa"], required: true },
  rfc: { type: String, trim: true },
  datosBancarios: {
    banco: { type: String, trim: true },
    clabe: { type: String, trim: true },
    titular: { type: String, trim: true }
  },
  documentos: {
    ineUrl: { type: String, trim: true },
    constanciaFiscalUrl: { type: String, trim: true }
  },
  validacion: {
    estado: { type: String, enum: ["pendiente", "aprobado", "rechazado"], default: "pendiente" },
    motivo: { type: String, trim: true }
  }
}, { timestamps: true });

module.exports = mongoose.model("Oferente", OferenteSchema);
