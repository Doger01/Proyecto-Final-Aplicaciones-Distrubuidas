const mongoose = require("mongoose");

const ProductoSchema = new mongoose.Schema({
  oferenteId: { type: mongoose.Schema.Types.ObjectId, ref: "Oferente", required: true, index: true },
  titulo: { type: String, required: true, trim: true },
  descripcion: { type: String, trim: true },
  precio: { type: Number, required: true, min: 0 },
  moneda: { type: String, default: "MXN" },
  existencias: { type: Number, default: 0, min: 0 },
  categoria: { type: String, trim: true },
  etiquetas: [{ type: String, trim: true }],
  imagenes: [{ type: String, trim: true }], // URLs
  activo: { type: Boolean, default: true }
}, { timestamps: true });

module.exports = mongoose.model("Producto", ProductoSchema);
