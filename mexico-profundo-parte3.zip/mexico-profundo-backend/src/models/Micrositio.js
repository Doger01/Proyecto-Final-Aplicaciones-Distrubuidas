const mongoose = require("mongoose");

const MicrositioSchema = new mongoose.Schema({
  oferenteId: { type: mongoose.Schema.Types.ObjectId, ref: "Oferente", required: true, unique: true },
  slug: { type: String, required: true, unique: true, index: true }, // ej: "nahuatzen"
  urlPath: { type: String, required: true }, // ej: "/artesano/nahuatzen"
  plantilla: { type: String, default: "base" },
  tema: {
    colorPrimario: { type: String, default: "#1f2937" },
    colorSecundario: { type: String, default: "#111827" }
  },
  descripcionCorta: { type: String, trim: true },
  logoUrl: { type: String, trim: true },
  ubicacion: {
    estado: { type: String, trim: true },
    municipio: { type: String, trim: true },
    coordenadas: { lat: Number, lng: Number }
  },
  contacto: {
    whatsapp: { type: String, trim: true },
    facebook: { type: String, trim: true },
    instagram: { type: String, trim: true }
  }
}, { timestamps: true });

module.exports = mongoose.model("Micrositio", MicrositioSchema);
