const router = require("express").Router();
const { list, getBySlug, update, changeSlug } = require("../controllers/micrositios.controller");
const { requireAuth, requireRole } = require("../middleware/auth");

router.get("/slug/:slug", getBySlug);

router.use(requireAuth);
router.get("/", requireRole("admin"), list);
router.patch("/:id", requireRole("admin", "oferente"), update);
router.post("/:id/slug", requireRole("admin"), changeSlug);

module.exports = router;
