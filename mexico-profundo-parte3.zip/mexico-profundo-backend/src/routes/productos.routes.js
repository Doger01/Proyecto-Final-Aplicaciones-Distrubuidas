const router = require("express").Router();
const { list, getOne, create, update, remove } = require("../controllers/productos.controller");
const { requireAuth } = require("../middleware/auth");
const { validate } = require("../middleware/validate");
const { createProductoSchema, updateProductoSchema } = require("../validators/productos.schemas");

router.get("/", list);
router.get("/:id", getOne);

router.use(requireAuth);
router.post("/", validate(createProductoSchema), create);
router.patch("/:id", validate(updateProductoSchema), update);
router.delete("/:id", remove);

module.exports = router;
