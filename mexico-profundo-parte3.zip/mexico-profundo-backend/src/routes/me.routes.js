const router = require("express").Router();
const { me } = require("../controllers/me.controller");
const { requireAuth } = require("../middleware/auth");

router.get("/me", requireAuth, me);

module.exports = router;
