const router = require("express").Router();
const { list, getOne, update, remove } = require("../controllers/oferentes.controller");
const { requireAuth, requireRole } = require("../middleware/auth");

router.use(requireAuth);

// Admin puede ver todo; oferente solo su propio registro (se maneja en UI; aquí dejamos admin-only para simplificar).
router.get("/", requireRole("admin"), list);
router.get("/:id", requireRole("admin"), getOne);
router.patch("/:id", requireRole("admin"), update);
router.delete("/:id", requireRole("admin"), remove);

module.exports = router;
