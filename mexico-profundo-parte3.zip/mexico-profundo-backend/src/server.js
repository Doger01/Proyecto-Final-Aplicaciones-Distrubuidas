require("dotenv").config();
const http = require("http");
const app = require("./app");
const { connectMongo } = require("./startup/mongo");

const PORT = Number(process.env.PORT || 4000);

async function bootstrap() {
  await connectMongo();
  const server = http.createServer(app);
  server.listen(PORT, () => {
    // eslint-disable-next-line no-console
    console.log(`[mexico-profundo-backend] listening on :${PORT}`);
  });
}

bootstrap().catch((err) => {
  // eslint-disable-next-line no-console
  console.error("Fatal error during startup:", err);
  process.exit(1);
});
