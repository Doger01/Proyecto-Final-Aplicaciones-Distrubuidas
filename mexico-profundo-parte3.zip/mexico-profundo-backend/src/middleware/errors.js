function notFoundHandler(req, res) {
  res.status(404).json({ error: "NOT_FOUND", path: req.originalUrl });
}

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  const status = err.statusCode || 500;
  const code = err.code || "INTERNAL_ERROR";
  const message = err.message || "Unexpected error";

  // eslint-disable-next-line no-console
  console.error(err);

  res.status(status).json({ error: code, message });
}

module.exports = { notFoundHandler, errorHandler };
