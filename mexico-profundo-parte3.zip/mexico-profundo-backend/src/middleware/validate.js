function validate(schema, prop = "body") {
  return (req, res, next) => {
    const { error, value } = schema.validate(req[prop], { abortEarly: false, stripUnknown: true });
    if (error) {
      return res.status(400).json({
        error: "VALIDATION_ERROR",
        details: error.details.map(d => ({ path: d.path.join("."), message: d.message }))
      });
    }
    req[prop] = value;
    return next();
  };
}

module.exports = { validate };
