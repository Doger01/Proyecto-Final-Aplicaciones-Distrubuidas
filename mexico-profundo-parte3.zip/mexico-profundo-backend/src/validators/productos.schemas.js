const Joi = require("joi");

const createProductoSchema = Joi.object({
  oferenteId: Joi.string().hex().length(24).required(),
  titulo: Joi.string().min(2).max(180).required(),
  descripcion: Joi.string().max(2000).allow("", null),
  precio: Joi.number().min(0).required(),
  moneda: Joi.string().max(8).default("MXN"),
  existencias: Joi.number().integer().min(0).default(0),
  categoria: Joi.string().max(80).allow("", null),
  etiquetas: Joi.array().items(Joi.string().max(40)).default([]),
  imagenes: Joi.array().items(Joi.string().uri().max(500)).default([]),
  activo: Joi.boolean().default(true)
});

const updateProductoSchema = Joi.object({
  titulo: Joi.string().min(2).max(180),
  descripcion: Joi.string().max(2000).allow("", null),
  precio: Joi.number().min(0),
  moneda: Joi.string().max(8),
  existencias: Joi.number().integer().min(0),
  categoria: Joi.string().max(80).allow("", null),
  etiquetas: Joi.array().items(Joi.string().max(40)),
  imagenes: Joi.array().items(Joi.string().uri().max(500)),
  activo: Joi.boolean()
});

module.exports = { createProductoSchema, updateProductoSchema };
