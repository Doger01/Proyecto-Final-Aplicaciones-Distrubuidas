const Joi = require("joi");

const registerSchema = Joi.object({
  email: Joi.string().email().required(),
  password: Joi.string().min(8).max(72).required(),

  nombreCompleto: Joi.string().min(3).max(120).required(),
  nombreComercial: Joi.string().min(2).max(120).required(),
  telefono: Joi.string().min(7).max(30).required(),
  localidad: Joi.string().min(2).max(120).required(),
  tipoActividad: Joi.string().valid("artesania", "turismo", "cooperativa").required(),

  rfc: Joi.string().max(20).allow("", null),
  datosBancarios: Joi.object({
    banco: Joi.string().max(80).allow("", null),
    clabe: Joi.string().max(25).allow("", null),
    titular: Joi.string().max(120).allow("", null)
  }).default({}),
  documentos: Joi.object({
    ineUrl: Joi.string().uri().max(500).allow("", null),
    constanciaFiscalUrl: Joi.string().uri().max(500).allow("", null)
  }).default({})
});

const loginSchema = Joi.object({
  email: Joi.string().email().required(),
  password: Joi.string().required()
});

module.exports = { registerSchema, loginSchema };
