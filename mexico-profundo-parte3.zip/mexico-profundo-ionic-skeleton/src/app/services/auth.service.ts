import { Injectable } from '@angular/core';
import { BehaviorSubject, tap } from 'rxjs';
import { ApiClientService } from './api-client.service';

export interface AuthState {
  token: string | null;
  user?: { id: string; email: string; role: string };
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private state$ = new BehaviorSubject<AuthState>({ token: localStorage.getItem('mp_token') });

  constructor(private api: ApiClientService) {}

  get token(): string | null {
    return this.state$.value.token;
  }

  authState() {
    return this.state$.asObservable();
  }

  login(email: string, password: string) {
    return this.api.post<{ token: string; user: any }>('/auth/login', { email, password }).pipe(
      tap((res) => {
        localStorage.setItem('mp_token', res.token);
        this.state$.next({ token: res.token, user: res.user });
      })
    );
  }

  register(payload: any) {
    return this.api.post<any>('/auth/register', payload).pipe(
      tap((res) => {
        localStorage.setItem('mp_token', res.token);
        this.state$.next({ token: res.token, user: res.user });
      })
    );
  }

  logout() {
    localStorage.removeItem('mp_token');
    this.state$.next({ token: null });
  }
}
