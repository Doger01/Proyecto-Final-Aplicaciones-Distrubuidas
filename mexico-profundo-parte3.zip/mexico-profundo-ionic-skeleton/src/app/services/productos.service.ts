import { Injectable } from '@angular/core';
import { ApiClientService } from './api-client.service';
import { AuthService } from './auth.service';

export interface Producto {
  _id?: string;
  oferenteId: string;
  titulo: string;
  descripcion?: string;
  precio: number;
  moneda?: string;
  existencias?: number;
  categoria?: string;
  etiquetas?: string[];
  imagenes?: string[];
  activo?: boolean;
}

@Injectable({ providedIn: 'root' })
export class ProductosService {
  constructor(private api: ApiClientService, private auth: AuthService) {}

  listar(params?: { oferenteId?: string; categoria?: string; q?: string }) {
    const qp = new URLSearchParams();
    if (params?.oferenteId) qp.set('oferenteId', params.oferenteId);
    if (params?.categoria) qp.set('categoria', params.categoria);
    if (params?.q) qp.set('q', params.q);
    const qs = qp.toString() ? `?${qp.toString()}` : '';
    return this.api.get<{ items: Producto[] }>(`/productos${qs}`);
  }

  crear(p: Producto) {
    const token = this.auth.token || undefined;
    return this.api.post<Producto>('/productos', p, token);
  }

  actualizar(id: string, patch: Partial<Producto>) {
    const token = this.auth.token || undefined;
    return this.api.patch<Producto>(`/productos/${id}`, patch, token);
  }

  eliminar(id: string) {
    const token = this.auth.token || undefined;
    return this.api.delete<void>(`/productos/${id}`, token);
  }
}
