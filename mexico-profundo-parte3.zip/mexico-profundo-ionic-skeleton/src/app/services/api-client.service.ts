import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class ApiClientService {
  private base = environment.apiBaseUrl;

  constructor(private http: HttpClient) {}

  get<T>(path: string, token?: string): Observable<T> {
    return this.http.get<T>(`${this.base}${path}`, { headers: this.headers(token) });
  }

  post<T>(path: string, body: any, token?: string): Observable<T> {
    return this.http.post<T>(`${this.base}${path}`, body, { headers: this.headers(token) });
  }

  patch<T>(path: string, body: any, token?: string): Observable<T> {
    return this.http.patch<T>(`${this.base}${path}`, body, { headers: this.headers(token) });
  }

  delete<T>(path: string, token?: string): Observable<T> {
    return this.http.delete<T>(`${this.base}${path}`, { headers: this.headers(token) });
  }

  private headers(token?: string): HttpHeaders {
    let h = new HttpHeaders({ 'Content-Type': 'application/json' });
    if (token) h = h.set('Authorization', `Bearer ${token}`);
    return h;
  }
}
