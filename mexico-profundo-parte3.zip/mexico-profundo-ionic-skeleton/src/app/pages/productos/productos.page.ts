import { Component, OnInit } from '@angular/core';
import { ProductosService, Producto } from '../../services/productos.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-productos',
  templateUrl: './productos.page.html',
})
export class ProductosPage implements OnInit {
  items: Producto[] = [];
  loading = true;
  errorMsg = '';
  q = '';

  // Nota: en una app real, este oferenteId se obtendría desde /me (perfil)
  oferenteId = '';

  constructor(private productos: ProductosService, private auth: AuthService) {}

  ngOnInit() {
    this.cargar();
  }

  cargar() {
    this.loading = true;
    this.errorMsg = '';
    this.productos.listar(this.oferenteId ? { oferenteId: this.oferenteId, q: this.q } : { q: this.q }).subscribe({
      next: (res) => { this.items = res.items; this.loading = false; },
      error: () => { this.errorMsg = 'No se pudieron cargar productos'; this.loading = false; }
    });
  }

  logout() {
    this.auth.logout();
    location.href = '/login';
  }
}
