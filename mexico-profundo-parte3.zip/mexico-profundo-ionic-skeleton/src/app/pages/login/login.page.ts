import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
})
export class LoginPage {
  email = '';
  password = '';
  loading = false;
  errorMsg = '';

  constructor(private auth: AuthService, private router: Router) {}

  onLogin() {
    this.loading = true;
    this.errorMsg = '';
    this.auth.login(this.email, this.password).subscribe({
      next: () => this.router.navigateByUrl('/tabs/productos', { replaceUrl: true }),
      error: (err) => {
        this.errorMsg = err?.error?.error || 'No se pudo iniciar sesión';
        this.loading = false;
      }
    });
  }
}
