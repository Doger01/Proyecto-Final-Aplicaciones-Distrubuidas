## Notas de integración rápida en proyecto Ionic (tabs)

1) Copia `services/` a `src/app/services/`.
2) Agrega páginas:
   - `pages/login/*`
   - `pages/productos/*`
3) En `app-routing.module.ts` registra rutas:
   - `/login` -> LoginPage
   - `/tabs/productos` -> ProductosPage (o ajusta al tab que uses)
4) Asegura `FormsModule` y `HttpClientModule` en `app.module.ts`.
