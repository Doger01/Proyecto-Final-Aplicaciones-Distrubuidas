export const environment = {
  production: false,
  apiBaseUrl: "http://localhost:4000/api"
};
