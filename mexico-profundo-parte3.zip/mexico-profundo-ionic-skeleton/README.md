# México Profundo - Ionic (skeleton)

Este folder trae el código **de las pantallas y servicios** para consumir la API del backend.
Recomendación: genera el proyecto base y luego copia los archivos de `src/` de este repositorio.

## 1) Crear proyecto Ionic (Angular)
```bash
npm i -g @ionic/cli
ionic start mexico-profundo-app tabs --type=angular --capacitor
cd mexico-profundo-app
```

## 2) Copiar archivos
Copia el contenido de `mexico-profundo-ionic-skeleton/src` dentro de `mexico-profundo-app/src`.

## 3) Configurar URL del backend
Edita `src/environments/environment.ts` y ajusta `apiBaseUrl`.

## 4) Ejecutar
```bash
ionic serve
```
