// Script de Prueba Simple para la API
const axios = require('axios');

const API_URL = 'http://localhost:5000';

async function probarAPI() {
  console.log('Probando API México Profundo...\n');

  try {
    // 1. Probar health check
    console.log('1. Probando health check...');
    const health = await axios.get(`${API_URL}/api/health`);
    console.log('✅ Health check:', health.data.status);

    // 2. Probar registro de usuario
    console.log('\n2. Probando registro de usuario...');
    const nuevoUsuario = {
      nombre: 'Juan',
      apellidos: 'Pérez García',
      correo: `test_${Date.now()}@email.com`,
      password: 'password123',
      telefono: '+52 999 123 4567',
      tipo: 'comprador'
    };

    const registro = await axios.post(`${API_URL}/api/auth/register`, nuevoUsuario);
    console.log('✅ Usuario registrado:', registro.data.usuario.correo);
    
    const token = registro.data.token;

    // 3. Probar login
    console.log('\n3. Probando login...');
    const login = await axios.post(`${API_URL}/api/auth/login`, {
      correo: nuevoUsuario.correo,
      password: nuevoUsuario.password
    });
    console.log('✅ Login exitoso:', login.data.usuario.nombre);

    // 4. Probar perfil
    console.log('\n4. Probando obtener perfil...');
    const perfil = await axios.get(`${API_URL}/api/auth/profile`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    console.log('✅ Perfil obtenido:', perfil.data.usuario.datosPersonales.nombre);

    // 5. Probar endpoints públicos
    console.log('\n5. Probando endpoints públicos...');
    
    const oferentes = await axios.get(`${API_URL}/api/oferentes`);
    console.log('✅ Oferentes:', oferentes.data.oferentes.length, 'encontrados');

    const productos = await axios.get(`${API_URL}/api/productos`);
    console.log('✅ Productos:', productos.data.message);

    const metodosPago = await axios.get(`${API_URL}/api/pagos/metodos`);
    console.log('✅ Métodos de pago:', metodosPago.data.metodos.length, 'disponibles');

    // 6. Probar cálculo de comisiones
    console.log('\n6. Probando cálculo de comisiones...');
    const comisiones = await axios.get(`${API_URL}/api/pagos/calcular-comisiones?monto=1000&metodoPago=stripe`);
    console.log('✅ Comisiones calculadas para $1000:', comisiones.data.comisiones);

    console.log('\n🎉 ¡Todas las pruebas pasaron exitosamente!');
    console.log('\nLa API está funcionando correctamente.');
    console.log('Puedes continuar desarrollando los demás endpoints.');

  } catch (error) {
    console.error('\n❌ Error en las pruebas:');
    if (error.response) {
      console.error('Status:', error.response.status);
      console.error('Data:', error.response.data);
    } else {
      console.error('Error:', error.message);
    }
    
    if (error.code === 'ECONNREFUSED') {
      console.log('\n💡 Asegúrate de que el servidor esté corriendo:');
      console.log('   npm run dev');
    }
  }
}

// Ejecutar pruebas si se llama directamente
if (require.main === module) {
  probarAPI();
}

module.exports = { probarAPI };