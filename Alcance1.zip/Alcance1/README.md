# API REST - Plataforma México Profundo

API REST completa para la comercialización de productos artesanales mexicanos. Proyecto escolar que simula un sistema de micrositios para artesanos, comunidades y cooperativas.

## Estructura de Archivos del Proyecto

### Archivos de Configuración
```
📄 package.json          # Dependencias y scripts del proyecto
📄 .env                  # Variables de entorno (tu configuración)
📄 .env.example          # Plantilla de variables de entorno
📄 .gitignore            # Archivos a ignorar en Git
```

### Servidor Principal
```
📄 server.js             # Servidor Express con todas las rutas y middleware
```

### Utilidades y Conexiones
```
📁 src/utils/
  📄 database.js         # Conexión a MongoDB Atlas
```

### Middleware (Funciones Intermedias)
```
📁 src/middleware/
  📄 auth.js             # Verificación de tokens JWT y roles de usuario
  📄 validation.js       # Validación de datos con esquemas Joi
  📄 upload.js           # Manejo de subida de archivos (simulado)
```

### Controladores (Lógica de Negocio)
```
📁 src/controllers/
  📄 authController.js   # Registro, login, perfiles de usuario
  📄 oferentesController.js  # Gestión de artesanos y cooperativas
  📄 pagosController.js  # Procesamiento de pagos simulados
```

### Rutas (Endpoints de la API)
```
📁 src/routes/
  📄 auth.js             # /api/auth/* - Autenticación y usuarios
  📄 oferentes.js        # /api/oferentes/* - Artesanos y cooperativas
  📄 pagos.js            # /api/pagos/* - Pagos y transacciones
  📄 productos.js        # /api/productos/* - Catálogo (placeholder)
  📄 pedidos.js          # /api/pedidos/* - Órdenes (placeholder)
  📄 micrositios.js      # /api/micrositios/* - Sitios web (placeholder)
  📄 admin.js            # /api/admin/* - Administración (placeholder)
```

### Servicios Externos
```
📁 src/services/
  📄 mockPaymentService.js  # Simulador de Stripe y MercadoPago
```

### Archivos de Prueba
```
📄 test-api.js           # Script para probar todos los endpoints
```

### Carpetas de Archivos
```
📁 uploads/              # Archivos subidos por usuarios (vacía)
```

## Archivos de Base de Datos (Carpeta Raíz)
```
📄 mongodb-connection.js     # Conexión básica a MongoDB
📄 setup-atlas-database.js  # Inicializar base de datos con índices
📄 load-sample-data.js      # Cargar datos de ejemplo
```

## Para Qué Sirve Cada Archivo

### 🔧 **Configuración y Servidor**

**`package.json`**
- Define las dependencias del proyecto (Express, MongoDB, JWT, etc.)
- Contiene scripts para ejecutar el servidor (`npm run dev`)
- Información del proyecto y versión

**`server.js`**
- Servidor principal que inicia la aplicación
- Configura middleware de seguridad (CORS, Rate Limiting)
- Define todas las rutas de la API
- Maneja errores de forma centralizada
- Conecta con MongoDB Atlas

**`.env`**
- Variables de configuración sensibles
- URL de MongoDB Atlas
- Claves secretas para JWT
- Configuración de puertos y límites

### 🔐 **Autenticación y Seguridad**

**`src/middleware/auth.js`**
- Verifica tokens JWT en rutas protegidas
- Controla roles de usuario (comprador, oferente, admin)
- Protege endpoints según permisos

**`src/controllers/authController.js`**
- Registro de nuevos usuarios
- Login con email y contraseña
- Generación de tokens JWT
- Gestión de perfiles de usuario

**`src/routes/auth.js`**
- Define endpoints de autenticación
- Aplica validaciones a los datos de entrada
- Rutas: `/api/auth/register`, `/api/auth/login`, etc.

### 📊 **Base de Datos**

**`src/utils/database.js`**
- Establece conexión con MongoDB Atlas
- Maneja el pool de conexiones
- Proporciona funciones para obtener la base de datos

**`setup-atlas-database.js`** (carpeta raíz)
- Crea índices para optimizar consultas
- Inserta configuración inicial del sistema
- Crea categorías de productos
- Configura usuario administrador

**`load-sample-data.js`** (carpeta raíz)
- Carga datos de ejemplo para pruebas
- Crea oferentes, productos y usuarios de muestra
- Útil para desarrollo y demostraciones

### 🏪 **Gestión de Oferentes**

**`src/controllers/oferentesController.js`**
- CRUD completo para artesanos y cooperativas
- Validación de documentos (INE, RFC)
- Creación automática de micrositios
- Estadísticas de ventas

**`src/routes/oferentes.js`**
- Endpoints para gestionar oferentes
- Rutas públicas y protegidas
- Subida de documentos e imágenes

### 💳 **Sistema de Pagos**

**`src/services/mockPaymentService.js`**
- Simula procesamiento con Stripe y MercadoPago
- Calcula comisiones automáticamente
- Genera reportes de ventas
- Maneja estados de transacciones

**`src/controllers/pagosController.js`**
- Procesa pagos simulados
- Genera reportes para oferentes
- Calcula comisiones de la plataforma
- Historial de transacciones

**`src/routes/pagos.js`**
- Endpoints de pagos y transacciones
- Métodos de pago disponibles
- Calculadora de comisiones

### ✅ **Validación y Archivos**

**`src/middleware/validation.js`**
- Esquemas de validación con Joi
- Valida emails, teléfonos, RFC
- Sanitiza datos de entrada
- Mensajes de error personalizados

**`src/middleware/upload.js`**
- Manejo de subida de archivos (simulado)
- Crea directorios necesarios
- Valida tipos y tamaños de archivo

### 🧪 **Pruebas**

**`test-api.js`**
- Prueba automática de todos los endpoints
- Verifica registro, login y funcionalidades
- Útil para desarrollo y demostraciones

## Instalación y Uso

### 1. Instalar dependencias
```bash
npm install
```

### 2. Configurar variables de entorno
```bash
# El archivo .env ya está configurado con MongoDB Atlas
```

### 3. Inicializar base de datos (opcional)
```bash
# Desde la carpeta raíz
node setup-atlas-database.js
node load-sample-data.js
```

### 4. Ejecutar servidor
```bash
npm run dev
```

### 5. Probar API
```bash
npm run test:api
```

## Endpoints Principales

### Autenticación
- `POST /api/auth/register` - Registrar usuario
- `POST /api/auth/login` - Iniciar sesión
- `GET /api/auth/profile` - Ver perfil (requiere token)

### Oferentes
- `GET /api/oferentes` - Listar artesanos y cooperativas
- `POST /api/oferentes` - Registrar nuevo oferente (requiere token)

### Pagos
- `GET /api/pagos/metodos` - Métodos de pago disponibles
- `POST /api/pagos/procesar` - Procesar pago simulado (requiere token)
- `GET /api/pagos/calcular-comisiones` - Calcular comisiones

### Sistema
- `GET /api/health` - Estado del servidor
- `GET /` - Información de la API

## Características del Proyecto

- **Simulación Educativa**: Todos los pagos y servicios son simulados
- **Base de Datos Real**: MongoDB Atlas con datos persistentes
- **Autenticación JWT**: Sistema de tokens seguro
- **Validación Robusta**: Validación de todos los datos de entrada
- **API RESTful**: Siguiendo estándares REST
- **Manejo de Errores**: Respuestas consistentes y útiles
- **Seguridad**: Rate limiting, CORS, validaciones

## Tecnologías Utilizadas

- **Node.js + Express**: Servidor web
- **MongoDB Atlas**: Base de datos en la nube
- **JWT**: Autenticación con tokens
- **Joi**: Validación de datos
- **bcrypt**: Encriptación de contraseñas
- **Helmet + CORS**: Seguridad web

Este proyecto demuestra conocimientos completos de desarrollo backend, bases de datos, APIs REST y buenas prácticas de programación.