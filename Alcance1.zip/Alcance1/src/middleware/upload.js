// Middleware Simplificado para Subida de Archivos
const fs = require('fs');

// Crear directorios si no existen
const crearDirectorios = () => {
  const directorios = [
    'uploads',
    'uploads/productos',
    'uploads/oferentes',
    'uploads/documentos'
  ];

  directorios.forEach(dir => {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  });
};

// Inicializar directorios
crearDirectorios();

// Middleware simulado para subida de archivos (para desarrollo)
const subirArchivosOferente = (req, res, next) => {
  // Simular archivos subidos para desarrollo
  req.files = {};
  next();
};

const subirImagen = (req, res, next) => {
  req.file = null;
  next();
};

const subirImagenes = (req, res, next) => {
  req.files = [];
  next();
};

const manejarErroresUpload = (err, req, res, next) => {
  console.error('Error de upload:', err);
  res.status(400).json({
    error: 'Error de subida de archivo',
    message: err.message
  });
};

module.exports = {
  subirImagen,
  subirImagenes,
  subirArchivosOferente,
  manejarErroresUpload
};