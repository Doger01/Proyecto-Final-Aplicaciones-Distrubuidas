// Middleware de Autenticación JWT
const jwt = require('jsonwebtoken');
const { obtenerDB } = require('../utils/database');
const { ObjectId } = require('mongodb');

// Verificar token JWT
const verificarToken = async (req, res, next) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({
        error: 'Acceso denegado',
        message: 'No se proporcionó token de autenticación'
      });
    }

    // Verificar y decodificar token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    // Buscar usuario en la base de datos
    const db = obtenerDB();
    const usuario = await db.collection('usuarios').findOne({
      _id: new ObjectId(decoded.userId)
    });

    if (!usuario) {
      return res.status(401).json({
        error: 'Token inválido',
        message: 'El usuario no existe'
      });
    }

    if (usuario.estado !== 'activo') {
      return res.status(401).json({
        error: 'Usuario inactivo',
        message: 'La cuenta está suspendida o inactiva'
      });
    }

    // Agregar información del usuario a la request
    req.usuario = {
      id: usuario._id,
      tipo: usuario.tipo,
      email: usuario.datosPersonales.correo,
      nombre: usuario.datosPersonales.nombre
    };

    next();
  } catch (error) {
    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({
        error: 'Token inválido',
        message: 'El token proporcionado no es válido'
      });
    }
    
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({
        error: 'Token expirado',
        message: 'El token ha expirado, inicia sesión nuevamente'
      });
    }

    console.error('Error en middleware de autenticación:', error);
    res.status(500).json({
      error: 'Error interno',
      message: 'Error al verificar autenticación'
    });
  }
};

// Verificar rol específico
const verificarRol = (rolesPermitidos) => {
  return (req, res, next) => {
    if (!req.usuario) {
      return res.status(401).json({
        error: 'No autenticado',
        message: 'Debe estar autenticado para acceder a este recurso'
      });
    }

    if (!rolesPermitidos.includes(req.usuario.tipo)) {
      return res.status(403).json({
        error: 'Acceso denegado',
        message: 'No tiene permisos para acceder a este recurso'
      });
    }

    next();
  };
};

// Verificar que el usuario sea administrador
const verificarAdmin = verificarRol(['administrador']);

// Verificar que el usuario sea oferente
const verificarOferente = verificarRol(['oferente', 'administrador']);

// Verificar que el usuario sea comprador
const verificarComprador = verificarRol(['comprador', 'administrador']);

// Verificar que el usuario sea el propietario del recurso o administrador
const verificarPropietario = async (req, res, next) => {
  try {
    const { id } = req.params;
    const db = obtenerDB();

    // Si es administrador, permitir acceso
    if (req.usuario.tipo === 'administrador') {
      return next();
    }

    // Verificar si el recurso pertenece al usuario
    let recurso;
    
    // Determinar el tipo de recurso basado en la ruta
    if (req.baseUrl.includes('/oferentes')) {
      recurso = await db.collection('oferentes').findOne({ _id: new ObjectId(id) });
      if (recurso && recurso.datosPersonales.correo === req.usuario.email) {
        return next();
      }
    } else if (req.baseUrl.includes('/productos')) {
      recurso = await db.collection('productos').findOne({ _id: new ObjectId(id) });
      if (recurso) {
        const oferente = await db.collection('oferentes').findOne({ _id: recurso.oferenteId });
        if (oferente && oferente.datosPersonales.correo === req.usuario.email) {
          return next();
        }
      }
    } else if (req.baseUrl.includes('/pedidos')) {
      recurso = await db.collection('pedidos').findOne({ _id: new ObjectId(id) });
      if (recurso && (recurso.compradorId.toString() === req.usuario.id.toString() || 
                     recurso.oferenteId.toString() === req.usuario.id.toString())) {
        return next();
      }
    }

    return res.status(403).json({
      error: 'Acceso denegado',
      message: 'No tiene permisos para acceder a este recurso'
    });

  } catch (error) {
    console.error('Error verificando propietario:', error);
    res.status(500).json({
      error: 'Error interno',
      message: 'Error al verificar permisos'
    });
  }
};

module.exports = {
  verificarToken,
  verificarRol,
  verificarAdmin,
  verificarOferente,
  verificarComprador,
  verificarPropietario
};