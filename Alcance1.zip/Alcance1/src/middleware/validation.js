// Middleware de Validación con Joi
const Joi = require('joi');

// Esquemas de validación

// Validación para registro de usuario
const esquemaRegistroUsuario = Joi.object({
  nombre: Joi.string().min(2).max(50).required()
    .messages({
      'string.min': 'El nombre debe tener al menos 2 caracteres',
      'string.max': 'El nombre no puede exceder 50 caracteres',
      'any.required': 'El nombre es obligatorio'
    }),
  apellidos: Joi.string().min(2).max(100).required()
    .messages({
      'string.min': 'Los apellidos deben tener al menos 2 caracteres',
      'string.max': 'Los apellidos no pueden exceder 100 caracteres',
      'any.required': 'Los apellidos son obligatorios'
    }),
  correo: Joi.string().email().required()
    .messages({
      'string.email': 'Debe ser un correo electrónico válido',
      'any.required': 'El correo es obligatorio'
    }),
  password: Joi.string().min(6).max(100).required()
    .messages({
      'string.min': 'La contraseña debe tener al menos 6 caracteres',
      'string.max': 'La contraseña no puede exceder 100 caracteres',
      'any.required': 'La contraseña es obligatoria'
    }),
  telefono: Joi.string().pattern(/^\+52\s?[0-9]{3}\s?[0-9]{3}\s?[0-9]{4}$/).required()
    .messages({
      'string.pattern.base': 'El teléfono debe tener formato +52 999 123 4567',
      'any.required': 'El teléfono es obligatorio'
    }),
  tipo: Joi.string().valid('comprador', 'oferente').default('comprador')
});

// Validación para login
const esquemaLogin = Joi.object({
  correo: Joi.string().email().required()
    .messages({
      'string.email': 'Debe ser un correo electrónico válido',
      'any.required': 'El correo es obligatorio'
    }),
  password: Joi.string().required()
    .messages({
      'any.required': 'La contraseña es obligatoria'
    })
});

// Validación para oferente
const esquemaOferente = Joi.object({
  tipoOferente: Joi.string().valid('artesano', 'comunidad', 'cooperativa').required()
    .messages({
      'any.only': 'El tipo debe ser: artesano, comunidad o cooperativa',
      'any.required': 'El tipo de oferente es obligatorio'
    }),
  datosPersonales: Joi.object({
    nombreCompleto: Joi.string().min(2).max(100).required(),
    nombreComercial: Joi.string().min(2).max(100).required(),
    correo: Joi.string().email().required(),
    telefono: Joi.string().pattern(/^\+52\s?[0-9]{3}\s?[0-9]{3}\s?[0-9]{4}$/).required(),
    rfc: Joi.string().min(12).max(13).required(),
    curp: Joi.string().length(18).optional()
  }).required(),
  ubicacion: Joi.object({
    estado: Joi.string().required(),
    municipio: Joi.string().required(),
    localidad: Joi.string().required(),
    direccion: Joi.string().required(),
    coordenadas: Joi.object({
      lat: Joi.number().min(-90).max(90).required(),
      lng: Joi.number().min(-180).max(180).required()
    }).optional()
  }).required(),
  micrositio: Joi.object({
    subdominio: Joi.string().min(3).max(50).pattern(/^[a-z0-9-]+$/).required()
      .messages({
        'string.pattern.base': 'El subdominio solo puede contener letras minúsculas, números y guiones'
      })
  }).required()
});

// Validación para producto
const esquemaProducto = Joi.object({
  nombre: Joi.string().min(2).max(200).required()
    .messages({
      'string.min': 'El nombre debe tener al menos 2 caracteres',
      'string.max': 'El nombre no puede exceder 200 caracteres',
      'any.required': 'El nombre es obligatorio'
    }),
  descripcion: Joi.string().min(10).max(2000).required()
    .messages({
      'string.min': 'La descripción debe tener al menos 10 caracteres',
      'string.max': 'La descripción no puede exceder 2000 caracteres',
      'any.required': 'La descripción es obligatoria'
    }),
  descripcionCorta: Joi.string().max(300).optional(),
  categoria: Joi.string().required()
    .messages({
      'any.required': 'La categoría es obligatoria'
    }),
  subcategoria: Joi.string().optional(),
  etiquetas: Joi.array().items(Joi.string()).max(10).optional(),
  precio: Joi.object({
    monto: Joi.number().positive().required()
      .messages({
        'number.positive': 'El precio debe ser mayor a 0',
        'any.required': 'El precio es obligatorio'
      }),
    moneda: Joi.string().valid('MXN', 'USD').default('MXN')
  }).required(),
  inventario: Joi.object({
    cantidad: Joi.number().integer().min(0).required(),
    tipoInventario: Joi.string().valid('limitado', 'ilimitado', 'bajo_pedido').default('limitado')
  }).required(),
  especificaciones: Joi.object({
    dimensiones: Joi.object({
      largo: Joi.number().positive().optional(),
      ancho: Joi.number().positive().optional(),
      alto: Joi.number().positive().optional(),
      peso: Joi.number().positive().optional()
    }).optional(),
    materiales: Joi.array().items(Joi.string()).optional(),
    colores: Joi.array().items(Joi.string()).optional(),
    tecnicaElaboracion: Joi.string().max(500).optional(),
    tiempoElaboracion: Joi.string().max(100).optional()
  }).optional()
});

// Validación para pedido
const esquemaPedido = Joi.object({
  items: Joi.array().items(
    Joi.object({
      productoId: Joi.string().required(),
      cantidad: Joi.number().integer().positive().required(),
      especificaciones: Joi.object().optional()
    })
  ).min(1).required()
    .messages({
      'array.min': 'Debe incluir al menos un producto',
      'any.required': 'Los items son obligatorios'
    }),
  direccionEnvio: Joi.object({
    nombre: Joi.string().required(),
    direccion: Joi.string().required(),
    ciudad: Joi.string().required(),
    estado: Joi.string().required(),
    codigoPostal: Joi.string().pattern(/^[0-9]{5}$/).required()
      .messages({
        'string.pattern.base': 'El código postal debe tener 5 dígitos'
      }),
    telefono: Joi.string().pattern(/^\+52\s?[0-9]{3}\s?[0-9]{3}\s?[0-9]{4}$/).required()
  }).required(),
  notas: Joi.string().max(500).optional()
});

// Middleware para validar datos
const validar = (esquema) => {
  return (req, res, next) => {
    const { error, value } = esquema.validate(req.body, {
      abortEarly: false, // Mostrar todos los errores
      stripUnknown: true // Remover campos no definidos en el esquema
    });

    if (error) {
      return res.status(400).json({
        error: 'Datos inválidos',
        message: 'Los datos proporcionados no son válidos',
        detalles: error.details.map(detail => ({
          campo: detail.path.join('.'),
          mensaje: detail.message,
          valorRecibido: detail.context?.value
        }))
      });
    }

    // Reemplazar req.body con los datos validados y limpiados
    req.body = value;
    next();
  };
};

// Validación para parámetros de URL
const validarParametros = (esquema) => {
  return (req, res, next) => {
    const { error, value } = esquema.validate(req.params);

    if (error) {
      return res.status(400).json({
        error: 'Parámetros inválidos',
        message: 'Los parámetros de la URL no son válidos',
        detalles: error.details.map(detail => ({
          parametro: detail.path.join('.'),
          mensaje: detail.message
        }))
      });
    }

    req.params = value;
    next();
  };
};

// Validación para query parameters
const validarQuery = (esquema) => {
  return (req, res, next) => {
    const { error, value } = esquema.validate(req.query);

    if (error) {
      return res.status(400).json({
        error: 'Parámetros de consulta inválidos',
        message: 'Los parámetros de consulta no son válidos',
        detalles: error.details.map(detail => ({
          parametro: detail.path.join('.'),
          mensaje: detail.message
        }))
      });
    }

    req.query = value;
    next();
  };
};

// Esquemas comunes para parámetros
const esquemaId = Joi.object({
  id: Joi.string().pattern(/^[0-9a-fA-F]{24}$/).required()
    .messages({
      'string.pattern.base': 'El ID debe ser un ObjectId válido de MongoDB'
    })
});

const esquemaPaginacion = Joi.object({
  page: Joi.number().integer().min(1).default(1),
  limit: Joi.number().integer().min(1).max(100).default(10),
  sort: Joi.string().optional(),
  order: Joi.string().valid('asc', 'desc').default('desc')
});

module.exports = {
  validar,
  validarParametros,
  validarQuery,
  esquemaRegistroUsuario,
  esquemaLogin,
  esquemaOferente,
  esquemaProducto,
  esquemaPedido,
  esquemaId,
  esquemaPaginacion
};