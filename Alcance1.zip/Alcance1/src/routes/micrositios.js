// Rutas de Micrositios
const express = require('express');
const router = express.Router();

// Placeholder para controlador de micrositios
const micrositiosController = {
  obtenerMicrositioPublico: (req, res) => {
    const { subdominio } = req.params;
    res.json({
      message: 'Endpoint de micrositio público en desarrollo',
      subdominio: subdominio,
      micrositio: {
        titulo: `Micrositio ${subdominio}`,
        descripcion: 'Micrositio en desarrollo',
        activo: true
      }
    });
  },
  
  actualizarMicrositio: (req, res) => {
    res.json({
      message: 'Endpoint de actualizar micrositio en desarrollo'
    });
  },
  
  obtenerEstadisticas: (req, res) => {
    res.json({
      message: 'Endpoint de estadísticas de micrositio en desarrollo',
      estadisticas: {
        visitas: 0,
        visitasUnicas: 0,
        tiempoPromedio: 0
      }
    });
  },
  
  registrarVisita: (req, res) => {
    res.json({
      message: 'Visita registrada (simulado)'
    });
  }
};

const { verificarToken, verificarOferente } = require('../middleware/auth');

// Rutas públicas
router.get('/:subdominio', micrositiosController.obtenerMicrositioPublico);
router.post('/:subdominio/visit', micrositiosController.registrarVisita);

// Rutas protegidas
router.put('/:id', verificarToken, verificarOferente, micrositiosController.actualizarMicrositio);
router.get('/:id/stats', verificarToken, verificarOferente, micrositiosController.obtenerEstadisticas);

module.exports = router;