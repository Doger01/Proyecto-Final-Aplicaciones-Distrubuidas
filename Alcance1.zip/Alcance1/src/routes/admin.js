// Rutas de Administración
const express = require('express');
const router = express.Router();

// Placeholder para controlador de admin
const adminController = {
  obtenerDashboard: (req, res) => {
    res.json({
      message: 'Dashboard administrativo en desarrollo',
      estadisticas: {
        oferentes: 0,
        productos: 0,
        pedidos: 0,
        ventas: 0
      }
    });
  },
  
  gestionarOferentes: (req, res) => {
    res.json({
      message: 'Gestión de oferentes en desarrollo',
      oferentes: []
    });
  },
  
  aprobarOferente: (req, res) => {
    res.json({
      message: 'Endpoint de aprobar oferente en desarrollo'
    });
  },
  
  obtenerEstadisticasGenerales: (req, res) => {
    res.json({
      message: 'Estadísticas generales en desarrollo',
      estadisticas: {}
    });
  },
  
  obtenerLogs: (req, res) => {
    res.json({
      message: 'Logs del sistema en desarrollo',
      logs: []
    });
  }
};

const { verificarToken, verificarAdmin } = require('../middleware/auth');

// Todas las rutas requieren autenticación de administrador
router.use(verificarToken);
router.use(verificarAdmin);

router.get('/dashboard', adminController.obtenerDashboard);
router.get('/oferentes', adminController.gestionarOferentes);
router.put('/oferentes/:id/approve', adminController.aprobarOferente);
router.get('/stats', adminController.obtenerEstadisticasGenerales);
router.get('/logs', adminController.obtenerLogs);

module.exports = router;