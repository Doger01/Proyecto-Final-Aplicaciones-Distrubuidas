// Controlador de Autenticación
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { obtenerDB } = require('../utils/database');
const { ObjectId } = require('mongodb');
// Función para crear errores personalizados
const crearError = (tipo, mensaje, status = 500) => {
  const error = new Error(mensaje);
  error.type = tipo;
  error.status = status;
  return error;
};

// Generar token JWT
const generarToken = (userId, tipo) => {
  return jwt.sign(
    { userId, tipo },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRE || '24h' }
  );
};

// Generar refresh token
const generarRefreshToken = (userId) => {
  return jwt.sign(
    { userId },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_REFRESH_EXPIRE || '7d' }
  );
};

// Registro de usuario
const registrarUsuario = async (req, res, next) => {
  try {
    const { nombre, apellidos, correo, password, telefono, tipo } = req.body;
    const db = obtenerDB();

    // Verificar si el usuario ya existe
    const usuarioExistente = await db.collection('usuarios').findOne({
      'datosPersonales.correo': correo
    });

    if (usuarioExistente) {
      throw crearError('conflict', 'Ya existe un usuario con este correo electrónico', 409);
    }

    // Encriptar contraseña
    const saltRounds = 10;
    const passwordHash = await bcrypt.hash(password, saltRounds);

    // Crear nuevo usuario
    const nuevoUsuario = {
      tipo: tipo || 'comprador',
      datosPersonales: {
        nombre,
        apellidos,
        correo,
        telefono
      },
      autenticacion: {
        passwordHash,
        ultimoAcceso: new Date(),
        intentosFallidos: 0,
        bloqueado: false
      },
      preferencias: {
        idioma: 'es',
        moneda: 'MXN',
        notificaciones: {
          email: true,
          sms: false,
          push: true
        }
      },
      fechaRegistro: new Date(),
      estado: 'activo'
    };

    // Si es oferente, agregar campos adicionales
    if (tipo === 'oferente') {
      nuevoUsuario.historialCompras = [];
      nuevoUsuario.wishlist = [];
    }

    const resultado = await db.collection('usuarios').insertOne(nuevoUsuario);

    // Generar tokens
    const token = generarToken(resultado.insertedId, nuevoUsuario.tipo);
    const refreshToken = generarRefreshToken(resultado.insertedId);

    // Registrar en logs
    await db.collection('logs').insertOne({
      tipo: 'acceso',
      usuarioId: resultado.insertedId,
      accion: 'registro',
      detalles: {
        tipoUsuario: nuevoUsuario.tipo,
        correo: correo
      },
      ip: req.ip,
      userAgent: req.get('User-Agent'),
      fecha: new Date(),
      nivel: 'info'
    });

    res.status(201).json({
      message: 'Usuario registrado exitosamente',
      usuario: {
        id: resultado.insertedId,
        nombre: nombre,
        apellidos: apellidos,
        correo: correo,
        tipo: nuevoUsuario.tipo
      },
      token,
      refreshToken
    });

  } catch (error) {
    next(error);
  }
};

// Inicio de sesión
const iniciarSesion = async (req, res, next) => {
  try {
    const { correo, password } = req.body;
    const db = obtenerDB();

    // Buscar usuario
    const usuario = await db.collection('usuarios').findOne({
      'datosPersonales.correo': correo
    });

    if (!usuario) {
      throw crearError('authorization', 'Credenciales inválidas', 401);
    }

    // Verificar si la cuenta está bloqueada
    if (usuario.autenticacion.bloqueado) {
      throw crearError('authorization', 'Cuenta bloqueada. Contacta al administrador', 401);
    }

    if (usuario.estado !== 'activo') {
      throw crearError('authorization', 'Cuenta inactiva', 401);
    }

    // Verificar contraseña
    const passwordValida = await bcrypt.compare(password, usuario.autenticacion.passwordHash);

    if (!passwordValida) {
      // Incrementar intentos fallidos
      await db.collection('usuarios').updateOne(
        { _id: usuario._id },
        { 
          $inc: { 'autenticacion.intentosFallidos': 1 },
          $set: { 
            'autenticacion.bloqueado': usuario.autenticacion.intentosFallidos >= 4 
          }
        }
      );

      throw crearError('authorization', 'Credenciales inválidas', 401);
    }

    // Resetear intentos fallidos y actualizar último acceso
    await db.collection('usuarios').updateOne(
      { _id: usuario._id },
      { 
        $set: { 
          'autenticacion.intentosFallidos': 0,
          'autenticacion.ultimoAcceso': new Date()
        }
      }
    );

    // Generar tokens
    const token = generarToken(usuario._id, usuario.tipo);
    const refreshToken = generarRefreshToken(usuario._id);

    // Registrar en logs
    await db.collection('logs').insertOne({
      tipo: 'acceso',
      usuarioId: usuario._id,
      accion: 'login',
      detalles: {
        tipoUsuario: usuario.tipo,
        correo: correo,
        exitoso: true
      },
      ip: req.ip,
      userAgent: req.get('User-Agent'),
      fecha: new Date(),
      nivel: 'info'
    });

    res.json({
      message: 'Inicio de sesión exitoso',
      usuario: {
        id: usuario._id,
        nombre: usuario.datosPersonales.nombre,
        apellidos: usuario.datosPersonales.apellidos,
        correo: usuario.datosPersonales.correo,
        tipo: usuario.tipo
      },
      token,
      refreshToken
    });

  } catch (error) {
    next(error);
  }
};

// Obtener perfil del usuario
const obtenerPerfil = async (req, res, next) => {
  try {
    const db = obtenerDB();
    const usuario = await db.collection('usuarios').findOne(
      { _id: new ObjectId(req.usuario.id) },
      { 
        projection: { 
          'autenticacion.passwordHash': 0,
          'autenticacion.salt': 0
        } 
      }
    );

    if (!usuario) {
      throw crearError('not_found', 'Usuario no encontrado', 404);
    }

    res.json({
      usuario: usuario
    });

  } catch (error) {
    next(error);
  }
};

// Actualizar perfil
const actualizarPerfil = async (req, res, next) => {
  try {
    const { nombre, apellidos, telefono, preferencias } = req.body;
    const db = obtenerDB();

    const actualizacion = {
      'datosPersonales.nombre': nombre,
      'datosPersonales.apellidos': apellidos,
      'datosPersonales.telefono': telefono,
      'preferencias': preferencias,
      'fechaUltimaActualizacion': new Date()
    };

    const resultado = await db.collection('usuarios').updateOne(
      { _id: new ObjectId(req.usuario.id) },
      { $set: actualizacion }
    );

    if (resultado.matchedCount === 0) {
      throw crearError('not_found', 'Usuario no encontrado', 404);
    }

    res.json({
      message: 'Perfil actualizado exitosamente'
    });

  } catch (error) {
    next(error);
  }
};

// Cambiar contraseña
const cambiarPassword = async (req, res, next) => {
  try {
    const { passwordActual, passwordNueva } = req.body;
    const db = obtenerDB();

    // Obtener usuario actual
    const usuario = await db.collection('usuarios').findOne({
      _id: new ObjectId(req.usuario.id)
    });

    if (!usuario) {
      throw crearError('not_found', 'Usuario no encontrado', 404);
    }

    // Verificar contraseña actual
    const passwordValida = await bcrypt.compare(passwordActual, usuario.autenticacion.passwordHash);

    if (!passwordValida) {
      throw crearError('authorization', 'Contraseña actual incorrecta', 401);
    }

    // Encriptar nueva contraseña
    const saltRounds = 10;
    const nuevaPasswordHash = await bcrypt.hash(passwordNueva, saltRounds);

    // Actualizar contraseña
    await db.collection('usuarios').updateOne(
      { _id: new ObjectId(req.usuario.id) },
      { 
        $set: { 
          'autenticacion.passwordHash': nuevaPasswordHash,
          'fechaUltimaActualizacion': new Date()
        }
      }
    );

    // Registrar en logs
    await db.collection('logs').insertOne({
      tipo: 'seguridad',
      usuarioId: new ObjectId(req.usuario.id),
      accion: 'cambio_password',
      detalles: {
        correo: req.usuario.email
      },
      ip: req.ip,
      userAgent: req.get('User-Agent'),
      fecha: new Date(),
      nivel: 'info'
    });

    res.json({
      message: 'Contraseña actualizada exitosamente'
    });

  } catch (error) {
    next(error);
  }
};

// Renovar token
const renovarToken = async (req, res, next) => {
  try {
    const { refreshToken } = req.body;

    if (!refreshToken) {
      throw crearError('authorization', 'Refresh token requerido', 401);
    }

    // Verificar refresh token
    const decoded = jwt.verify(refreshToken, process.env.JWT_SECRET);
    
    // Buscar usuario
    const db = obtenerDB();
    const usuario = await db.collection('usuarios').findOne({
      _id: new ObjectId(decoded.userId)
    });

    if (!usuario || usuario.estado !== 'activo') {
      throw crearError('authorization', 'Usuario no válido', 401);
    }

    // Generar nuevo token
    const nuevoToken = generarToken(usuario._id, usuario.tipo);

    res.json({
      token: nuevoToken
    });

  } catch (error) {
    if (error.name === 'JsonWebTokenError' || error.name === 'TokenExpiredError') {
      return next(crearError('authorization', 'Refresh token inválido o expirado', 401));
    }
    next(error);
  }
};

// Cerrar sesión
const cerrarSesion = async (req, res, next) => {
  try {
    const db = obtenerDB();

    // Registrar en logs
    await db.collection('logs').insertOne({
      tipo: 'acceso',
      usuarioId: new ObjectId(req.usuario.id),
      accion: 'logout',
      detalles: {
        correo: req.usuario.email
      },
      ip: req.ip,
      userAgent: req.get('User-Agent'),
      fecha: new Date(),
      nivel: 'info'
    });

    res.json({
      message: 'Sesión cerrada exitosamente'
    });

  } catch (error) {
    next(error);
  }
};

module.exports = {
  registrarUsuario,
  iniciarSesion,
  obtenerPerfil,
  actualizarPerfil,
  cambiarPassword,
  renovarToken,
  cerrarSesion
};