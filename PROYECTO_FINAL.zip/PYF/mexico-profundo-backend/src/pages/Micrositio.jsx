import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';

export default function Micrositio() {
  const { slug } = useParams();
  const [data, setData] = useState(null);

  useEffect(() => {
    fetch(`${process.env.REACT_APP_API_URL}/api/micrositios/slug/${slug}`)
      .then(r => r.json())
      .then(setData);
  }, [slug]);

  if (!data) return <div>Cargando...</div>;
  const { micrositio, productos } = data;

  return (
    <div>
      <header>
        <h1>{micrositio.oferente.nombreComercial || micrositio.oferente.nombre}</h1>
        <p>{micrositio.config?.descripcion}</p>
      </header>
      <section>
        {productos.map(p => (
          <article key={p._id}>
            <img src={p.imagenes?.[0]?.url} alt={p.imagenes?.[0]?.alt || p.nombre} width="200"/>
            <h3>{p.nombre}</h3>
            <p>{p.descripcion}</p>
            <p>{p.precio} MXN</p>
          </article>
        ))}
      </section>
    </div>
  );
}
