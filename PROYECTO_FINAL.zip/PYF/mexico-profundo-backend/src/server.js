require('dotenv').config();
const express = require('express');
const cors = require('cors');
const connectDB = require('./config/db');

const app = express();
app.use(cors());
app.use(express.json({ limit: '5mb' })); // acepta JSON y uploads base64 sencillos

connectDB();

// rutas
app.get('/', (req, res) => res.send('API México Profundo'));

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Server en puerto ${PORT}`));

const oferentesRouter = require('./routes/oferentes');
app.use('/api/oferentes', oferentesRouter);

const productosRouter = require('./routes/productos');
app.use('/api/productos', productosRouter);


