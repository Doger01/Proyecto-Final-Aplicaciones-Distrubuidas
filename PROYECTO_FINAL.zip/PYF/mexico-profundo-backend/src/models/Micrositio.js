const mongoose = require('mongoose');

const MicrositioSchema = new mongoose.Schema({
  oferente: { type: mongoose.Schema.Types.ObjectId, ref: 'Oferente', required: true },
  slug: { type: String, required: true, unique: true }, // ej: nahuatzen
  config: {
    colores: Object,
    logotipo: String,
    descripcion: String
  }
});

module.exports = mongoose.model('Micrositio', MicrositioSchema);
