const mongoose = require('mongoose');

const OferenteSchema = new mongoose.Schema({
  nombre: { type: String, required: true },
  nombreComercial: String,
  email: { type: String, required: true, unique: true },
  telefono: String,
  localidad: String,
  tipoActividad: String,
  rfc: String,
  datosBancarios: {
    banco: String,
    cuenta: String,
    clabe: String
  },
  documentos: [{ filename: String, url: String }],
  isValidated: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Oferente', OferenteSchema);
