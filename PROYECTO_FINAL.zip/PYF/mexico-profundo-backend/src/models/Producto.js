const mongoose = require('mongoose');

const ProductoSchema = new mongoose.Schema({
  oferente: { type: mongoose.Schema.Types.ObjectId, ref: 'Oferente', required: true },
  nombre: String,
  descripcion: String,
  precio: Number,
  stock: Number,
  categorias: [String],
  imagenes: [{ url: String, alt: String }],
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Producto', ProductoSchema);
