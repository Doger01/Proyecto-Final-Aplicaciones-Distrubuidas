const express = require('express');
const router = express.Router();
const Producto = require('../models/Producto');

// crear producto
router.post('/', async (req, res) => {
  try {
    const producto = new Producto(req.body);
    await producto.save();
    res.json(producto);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// leer productos por oferente
router.get('/oferente/:id', async (req, res) => {
  const productos = await Producto.find({ oferente: req.params.id });
  res.json(productos);
});

// actualizar
router.put('/:id', async (req, res) => {
  const p = await Producto.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(p);
});

// eliminar
router.delete('/:id', async (req, res) => {
  await Producto.findByIdAndDelete(req.params.id);
  res.json({ ok: true });
});

module.exports = router;
