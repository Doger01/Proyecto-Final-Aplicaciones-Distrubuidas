const express = require('express');
const router = express.Router();
const Oferente = require('../models/Oferente');

// Registro sin password (solo datos). En producción agrega autenticación.
router.post('/registro', async (req, res) => {
  try {
    const data = req.body;
    const existe = await Oferente.findOne({ email: data.email });
    if (existe) return res.status(400).json({ msg: 'Email ya registrado' });

    const oferente = new Oferente(data);
    await oferente.save();
    // en produccion enviar email para confirmacion
    res.json({ ok: true, oferente });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
