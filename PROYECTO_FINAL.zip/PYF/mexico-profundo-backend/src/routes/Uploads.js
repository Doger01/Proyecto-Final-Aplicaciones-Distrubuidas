const express = require('express');
const router = express.Router();
const multer = require('multer');
const cloudinary = require('../services/cloudinary');
const { CloudinaryStorage } = require('multer-storage-cloudinary');

const storage = new CloudinaryStorage({
  cloudinary,
  params: { folder: 'mexico_profundo' }
});
const parser = multer({ storage });

router.post('/imagen', parser.single('file'), (req, res) => {
  res.json({ url: req.file.path, filename: req.file.filename });
});

module.exports = router;
